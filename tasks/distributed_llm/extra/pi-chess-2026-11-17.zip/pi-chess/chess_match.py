#!/usr/bin/env python3
"""Serve chess-gpt-board, or referee a match between two board/chat APIs.

Run with --help, serve --help, or match --help. Only the native model server
needs PyTorch and the upstream model.py; the referee needs chess==1.11.2.
"""

import argparse
from base64 import b64encode
from datetime import datetime, timezone
from functools import partial
from http.server import BaseHTTPRequestHandler, HTTPServer, SimpleHTTPRequestHandler, ThreadingHTTPServer
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from threading import Condition, Lock, Thread
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from urllib.parse import urlsplit

try:
    import chess
    import chess.engine
    import chess.pgn
    import chess.svg
except ImportError:
    raise SystemExit("Install the referee dependency: python3 -m pip install chess==1.11.2")


ELOS = tuple(range(800, 2401, 200))
RESULTS = ("mover-wins", "white-wins", "black-wins", "draw")
PIECE_NAMES = {"p": "Pawn", "n": "Knight", "b": "Bishop", "r": "Rook", "q": "Queen", "k": "King"}
PIECE_IMAGES = {symbol: "data:image/svg+xml;base64," + b64encode(
    chess.svg.piece(chess.Piece.from_symbol(symbol), size=96).encode("utf-8")).decode("ascii")
    for symbol in "PNBRQKpnbrqk"}
MATERIAL_VALUES = {chess.PAWN: 1, chess.KNIGHT: 3, chess.BISHOP: 3, chess.ROOK: 5, chess.QUEEN: 9}


def material_summary(board):
    """Count current material and actual captures, including EP and promotions."""
    captured = {chess.WHITE: [], chess.BLACK: []}
    position = board.root()
    for move in board.move_stack:
        square = move.to_square
        if position.is_en_passant(move):
            square += -8 if position.turn else 8
        piece = position.piece_at(square)
        if piece is not None and position.is_capture(move):
            captured[position.turn].append(piece.symbol())
        position.push(move)
    totals = {color: sum(value * len(board.pieces(kind, color))
                         for kind, value in MATERIAL_VALUES.items())
              for color in (chess.WHITE, chess.BLACK)}
    return {name: dict(points=totals[color], advantage=max(0, totals[color] - totals[not color]),
                       captured=sorted(captured[color], key=lambda symbol: "pnbrqk".index(symbol.lower())))
            for name, color in (("white", chess.WHITE), ("black", chess.BLACK))}


def piece_token(piece):
    if piece is None:
        return "<blank>"
    color = "White" if piece.color else "Black"
    return f"<{color}_{PIECE_NAMES[piece.symbol().lower()]}>"


def encode_qwen3_chess(board):
    """AIcrowd's chess_encode_special_tokens.jinja format, without Jinja.

    The checkpoint's model card links this training/evaluation code. Squares
    run a1..h8 from White's fixed viewpoint, even on Black's turn.
    """
    squares = "".join(f"<{chess.square_name(s)}>{piece_token(board.piece_at(s))}" for s in chess.SQUARES)
    _, turn, castling, ep, halfmove, fullmove = board.fen().split()
    color = "White" if turn == "w" else "Black"
    moves = []
    for move in board.legal_moves:
        encoded = f"<{chess.square_name(move.from_square)}><{chess.square_name(move.to_square)}>"
        if move.promotion:
            encoded += f"<{color}_{PIECE_NAMES[chess.piece_symbol(move.promotion)]}>"
        moves.append(encoded)
    return (f"<chess_position>{squares}|{color}|{castling}|{ep}|{halfmove}|{fullmove}|"
            + " ".join(moves) + "</chess_position>")


def parse_qwen3_move(board, reply):
    """Read one committed move after optional reasoning; never choose from it."""
    if not isinstance(reply, str) or not reply.strip():
        raise ValueError("Reply must contain a committed chess move")
    answer = reply.strip()
    if answer.startswith("<think>"):
        end = answer.find("</think>")
        if end < 0:
            raise ValueError("Unfinished <think> block; increase --max-tokens")
        answer = answer[end + len("</think>"):].strip()
    if "<think>" in answer or "</think>" in answer:
        raise ValueError("Malformed reasoning block")
    tag = re.fullmatch(r"<uci_move>\s*([a-h][1-8][a-h][1-8][qrbn]?)\s*</uci_move>", answer)
    if tag:
        return parse_move(board, tag.group(1))
    # Some checkpoints emit the same square/piece tokens as the input moves.
    encoded = re.fullmatch(r"<([a-h][1-8])>\s*<([a-h][1-8])>(?:\s*<(White|Black)_(Queen|Rook|Bishop|Knight)>)?", answer)
    if encoded:
        source, target, color, promotion = encoded.groups()
        if color is not None and color != ("White" if board.turn else "Black"):
            raise ValueError("Promotion token has the wrong color")
        suffix = {"Queen": "q", "Rook": "r", "Bishop": "b", "Knight": "n", None: ""}[promotion]
        return parse_move(board, source + target + suffix)
    # Plain UCI/SAN is supported, but not prose or a list of possible moves.
    return parse_move(board, answer)


def chat_messages(match, protocol, history, attempts):
    if protocol == "qwen3-chess":
        # The publisher-linked evaluator sends a single user turn. No generic
        # persona, FEN prose, or rolling game history is prepended to this format.
        prompt = encode_qwen3_chess(match.board)
        if attempts:
            # Repeat the full position on retries so the final turn still has
            # the same board format. Prior rejected attempts remain in the log.
            prompt = attempts[-1][1] + "\n" + prompt
        return [{"role": "user", "content": prompt}]
    color = "White" if match.board.turn else "Black"
    prompt = (f"You play {color}. Current FEN: {match.board.fen()}\n"
              f"Board (uppercase White, lowercase Black):\n{match.board}\n"
              f"Initial FEN: {match.initial_fen}\n"
              f"Accepted UCI history: {' '.join(history) or '(none)'}\n"
              f"Legal UCI moves: {' '.join(sorted(m.uci() for m in match.board.legal_moves))}\n"
              "Reply with exactly one listed UCI move, including a promotion suffix when needed.")
    messages = [{"role": "system", "content": "Play standard chess. Choose one legal move. Return only its UCI notation."},
                {"role": "user", "content": prompt}]
    for reply, correction in attempts:
        messages.extend([{"role": "assistant", "content": reply}, {"role": "user", "content": correction}])
    return messages


def now():
    return datetime.now(timezone.utc).isoformat()


def request_json(url, payload=None, timeout=180):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urlopen(request, timeout=timeout) as response:
            return json.load(response)
    except HTTPError as error:
        detail = error.read(4096).decode("utf-8", errors="replace")
        raise ValueError(f"{url}: HTTP {error.code}: {detail}") from error


def valid_board(fen):
    board = chess.Board(fen)
    if not board.is_valid():
        raise ValueError("FEN is not a valid standard-chess position")
    return board


def replay(initial_fen, history):
    """Keep the move stack: FEN alone loses the model's eight-move history."""
    board = valid_board(initial_fen)
    if not isinstance(history, list) or not all(isinstance(m, str) for m in history):
        raise ValueError("history must be a list of UCI strings")
    for uci in history:
        move = chess.Move.from_uci(uci)
        if move not in board.legal_moves:
            raise ValueError(f"Illegal history move: {uci}")
        board.push(move)
    return board


def parse_move(board, reply):
    """Require a single move; never fish a legal alternative out of prose."""
    if not isinstance(reply, str) or not reply.strip():
        raise ValueError("Reply must contain exactly one UCI or SAN move")
    token = reply.strip()
    try:
        move = chess.Move.from_uci(token)
    except ValueError:
        try:
            move = board.parse_san(token)
        except ValueError as error:
            raise ValueError(f"Invalid or illegal move: {token[:160]}") from error
    if move not in board.legal_moves:  # Also rejects null moves such as 0000/--.
        raise ValueError(f"Illegal move: {token[:160]}")
    return move


def result_token(setting, board):
    if setting == "mover-wins":
        return "<white_wins>" if board.turn else "<black_wins>"
    return {"white-wins": "<white_wins>", "black-wins": "<black_wins>", "draw": "<draw>"}[setting]


class BoardPolicy:
    """Adapter around the publisher's ChessModel, including its Black mirroring."""

    def __init__(self, model, model_id):
        self.model, self.model_id = model, model_id

    def choose(self, payload):
        board = replay(payload["initial_fen"], payload["history"])
        if board.fen() != valid_board(payload["fen"]).fen():
            raise ValueError("fen disagrees with initial_fen + history")
        if board.is_game_over():
            raise ValueError("Position is already terminal")
        white, black = payload.get("white_elo", 2400), payload.get("black_elo", 2400)
        if white not in ELOS or black not in ELOS:
            raise ValueError("Elo must be 800..2400 in steps of 200")
        result = payload.get("result", "<white_wins>" if board.turn else "<black_wins>")
        if result not in ("<white_wins>", "<black_wins>", "<draw>"):
            raise ValueError("Invalid result conditioning token")
        excluded = payload.get("excluded_moves", [])
        if not isinstance(excluded, list) or not all(isinstance(m, str) for m in excluded):
            raise ValueError("excluded_moves must be a list of UCI strings")
        candidates = [m for m in board.legal_moves if m.uci() not in excluded]
        if not candidates:
            raise ValueError("No legal candidates remain")
        # Upstream uses board.move_stack, keeps its last eight moves, and mirrors
        # board/history/ratings/output for Black. Do not mirror anything here.
        probs = self.model.move_probs(board, result, f"<elo_{white}>", f"<elo_{black}>")
        scores = {m: float(probs[self.model.move_to_id[m.uci()]]) for m in candidates}
        if not all(math.isfinite(p) and p >= 0 for p in scores.values()):
            raise ValueError("Model returned invalid probabilities")
        move = max(candidates, key=scores.get)
        return {"move": move.uci(), "model": self.model_id, "probability": scores[move]}


def api_handler(policy):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def respond(self, code, data):
            body = json.dumps(data).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path == "/v1/models":
                self.respond(200, {"object": "list", "data": [{"id": policy.model_id, "object": "model"}]})
            else:
                self.respond(404, {"error": "Use GET /v1/models or POST /v1/chess/move"})

        def do_POST(self):
            if self.path != "/v1/chess/move":
                self.respond(404, {"error": "This board encoder uses POST /v1/chess/move"})
                return
            try:
                self.connection.settimeout(30)
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 1024 * 1024:
                    raise ValueError("JSON request must be 1..1048576 bytes")
                payload = json.loads(self.rfile.read(length))
                if not isinstance(payload, dict):
                    raise ValueError("Request must be a JSON object")
                response = policy.choose(payload)
            except (ValueError, KeyError, TypeError) as error:
                self.respond(400, {"error": str(error)})
            except Exception as error:
                print(f"Inference failed: {error}", file=sys.stderr, flush=True)
                self.respond(500, {"error": "Inference failed; inspect the API terminal"})
            else:
                self.respond(200, response)

    return Handler


def serve(args):
    directory = args.model_dir.resolve()
    code = args.model_code.resolve()
    for path in (code, directory / f"config_{args.size}.json", directory / f"model_{args.size}.safetensors"):
        if not path.is_file():
            raise ValueError(f"Missing model file: {path}")
    os.environ["CHESS_MODEL_DIR"] = str(directory)  # Must precede importing upstream model.py.
    import torch

    torch.set_num_threads(args.threads)
    spec = importlib.util.spec_from_file_location("chess_board_upstream", code)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    policy = BoardPolicy(module.ChessModel(args.size), f"chess-gpt-board-{args.size}")
    # Serialize inference so CPU threads are shared by one forward pass at a time.
    with HTTPServer((args.host, args.port), api_handler(policy)) as server:
        print(f"Loaded {policy.model_id}. API on {args.host}:{server.server_port}/v1", flush=True)
        server.serve_forever()


# Recreates the green/paper board-and-sidebar layout from the historical
# solution/chess_web.html. SVG keeps this single file free of Pillow/CDN assets.
HTML = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pi Chess · Big Data Lab</title><style>
:root{color-scheme:light;--paper:#f6f4ec;--ink:#243c34;--muted:#69756c;--line:#daddd0;--accent:#315c47}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:15px/1.5 system-ui,sans-serif}
header{padding:18px max(24px,calc((100vw - 1392px)/2));border-bottom:1px solid var(--line);display:flex;justify-content:space-between;gap:20px}.brand{font-weight:700;letter-spacing:.03em}#connection{font-size:12px;color:var(--muted)}
main{max-width:1440px;margin:auto;padding:34px 24px}.subtitle{color:var(--muted);font-size:13px}
nav{display:flex;gap:9px;flex-wrap:wrap}a{padding:10px 16px;border:1px solid var(--line);border-radius:7px;color:var(--ink);font-size:12px;text-decoration:none}a.primary{background:var(--accent);color:white}select:disabled{color:var(--muted);background:#eeeee7;cursor:default}
.layout{display:grid;grid-template-columns:minmax(0,1fr) minmax(320px,400px);gap:26px;align-items:stretch}.board-column{display:grid;grid-template-columns:38px minmax(0,1fr);gap:10px;align-items:stretch;align-self:start;min-width:0}.board-panel{grid-column:2;grid-row:1;min-width:0}.board-panel,.panel,.player{background:#fbfaf5;border:1px solid var(--line);border-radius:10px;overflow:hidden}.board-top,.board-bottom{padding:14px 20px;display:flex;justify-content:space-between;gap:12px;font-size:12px}.board-bottom{color:var(--muted);border-top:1px solid var(--line);align-items:center;flex-wrap:wrap}.board-bottom nav{flex:1 1 auto;gap:6px}.board-bottom a{padding:7px 9px;font-size:11px}.board-bottom #updated{margin-left:auto;white-space:nowrap}#board{display:block;width:100%;height:auto;aspect-ratio:1}
.eval-panel{grid-column:1;grid-row:1;width:38px;display:flex;flex-direction:column;gap:8px;align-items:center;padding:14px 0;color:var(--muted);font-size:11px}.eval-panel[hidden]{display:none}.eval-track{position:relative;flex:1;width:24px;min-height:160px;background:#26312c;border:1px solid #abb6ac;border-radius:5px;overflow:hidden}.eval-fill{position:absolute;bottom:0;left:0;width:100%;height:50%;background:#fbfaf5;transition:height .25s ease}.eval-track.unavailable{opacity:.45}.eval-score{font:11px ui-monospace,monospace;white-space:nowrap;color:var(--ink)}
.side{min-width:0}.side-content{display:grid;gap:16px}.players{display:grid;grid-template-columns:1fr 1fr;gap:10px}.player{padding:14px;min-width:0}.player.active{border-color:#648772;box-shadow:inset 0 3px #648772}.label{font-size:10px;text-transform:uppercase;letter-spacing:.13em;color:var(--muted)}.player h2{font-size:16px;margin:6px 0}.endpoint{font:11px ui-monospace,monospace;overflow-wrap:anywhere;color:var(--muted)}
.status{padding:16px 18px;background:#e7ecdf;border:1px solid #d6dfce;border-radius:9px}.status h2{font-size:14px;margin:0}.status p{font-size:12px;color:var(--muted);overflow-wrap:anywhere}.stats{display:grid;grid-template-columns:repeat(3,1fr);border-top:1px solid #cfd9c8;padding-top:12px}.stats strong{font:24px Georgia,serif;display:block}.stats span{font-size:10px;color:var(--muted)}
.panel h2{font-size:11px;margin:0;padding:12px 16px;border-bottom:1px solid var(--line)}.scroll{max-height:252px;overflow:auto}table{width:100%;border-collapse:collapse;font:13px ui-monospace,monospace;text-align:left}th,td{padding:8px 15px;border-bottom:1px solid #eceee4}th{font-size:11px;color:var(--muted)}pre{margin:0;padding:13px 16px;max-height:160px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.6 ui-monospace,monospace}footer{margin-top:23px;color:var(--muted);font-size:11px}
.controls{padding:16px;display:grid;gap:12px}.fields{display:flex;gap:12px;flex-wrap:wrap}.fields label{flex:1;min-width:120px;font-size:12px}select,input,button{font:inherit;border:1px solid var(--line);border-radius:6px;padding:10px;background:#fff;color:var(--ink)}select,input{display:block;width:100%;margin-top:5px}button{cursor:pointer}button.primary{background:var(--accent);color:#fff}button:disabled{cursor:default;opacity:.55}.control-message{font-size:12px;color:var(--muted);margin:0;min-height:18px}.board-wrap{position:relative}#squares{position:absolute;inset:3.846153846%;display:grid;grid-template-columns:repeat(8,1fr);grid-template-rows:repeat(8,1fr);pointer-events:none}#squares button{padding:0;border:0;border-radius:0;background:transparent;position:relative;opacity:1;pointer-events:auto}#squares button:disabled{pointer-events:none}#squares .selected{box-shadow:inset 0 0 0 4px #e2b650}#squares .target:after{content:'';position:absolute;width:24%;height:24%;border-radius:50%;background:#254c3ab0;top:38%;left:38%}#squares button:focus-visible{outline:3px solid #e2b650;outline-offset:-3px}#human-form[hidden]{display:none}.move-entry{display:grid;grid-template-columns:1fr 105px;gap:10px}.move-entry label{font-size:12px}
#board,#squares{user-select:none;-webkit-user-select:none}#squares button:enabled{touch-action:none}#squares .movable{cursor:grab}#squares .drag-source{cursor:grabbing}#squares .drop-target{box-shadow:inset 0 0 0 4px #e2b650}#drag-piece{position:fixed;z-index:1000;pointer-events:none;transform:translate(-50%,-50%);filter:drop-shadow(0 5px 4px #0005);user-select:none}
.square-preview{position:absolute;inset:0;display:block;width:100%;height:100%;pointer-events:none}.square-preview[hidden]{display:none}.material-row{display:flex;align-items:center;gap:8px;height:36px;padding:6px 16px;border-top:1px solid var(--line);font-size:11px}.material-name{flex:0 0 42px}.material-pieces{display:flex;align-items:center;flex:0 1 auto;min-width:0;height:24px;overflow-x:auto;overflow-y:hidden;padding-right:5px;scrollbar-width:none}.material-pieces::-webkit-scrollbar{display:none}.material-pieces img{width:22px;height:22px;flex:0 0 22px;margin-right:-5px}.material-advantage{flex:0 0 auto;text-align:left;font-size:13px;color:var(--accent)}
@media(min-width:1201px){.layout>.side{position:relative;min-height:0}.layout .side-content{position:absolute;inset:0;display:flex;flex-direction:column;gap:16px}.layout .side-content>.controls,.layout .players,.layout .status,.layout .reply-panel{flex:0 0 auto}.layout .history-panel{display:flex;flex:1 1 0;min-height:0;flex-direction:column}.layout .history-panel h2{flex:0 0 auto}.layout .history-panel .scroll{flex:1;min-height:0;max-height:none}}
@media(max-width:1200px){.layout{grid-template-columns:1fr}main{padding:26px 18px}}
</style></head><body>
<header><span class="brand">♞ PI CHESS / Big Data Lab</span><span id="connection">Connecting…</span></header>
<main>
<div class="layout" id="match-layout"><div class="board-column"><aside class="eval-panel" id="eval-panel" aria-label="Stockfish position evaluation" hidden><span aria-hidden="true">B</span><div class="eval-track unavailable" id="eval-track" role="meter" aria-label="Position evaluation from White's perspective" aria-valuemin="0" aria-valuemax="100" aria-valuetext="Not evaluated"><div class="eval-fill" id="eval-fill"></div></div><span aria-hidden="true">W</span><strong class="eval-score" id="eval-score">—</strong></aside><section class="board-panel" aria-label="Live chessboard"><div class="board-top"><strong id="turn">White to move</strong><span id="result">Starting position</span></div><div class="material-row" id="material-top"><strong class="material-name" id="material-top-name">Black</strong><div class="material-pieces" id="material-top-pieces" aria-label="Captured pieces"></div><strong class="material-advantage" id="material-top-advantage"></strong></div><div class="board-wrap"><img id="board" src="board.svg" alt="Chessboard" draggable="false"><div id="squares" aria-label="Choose a piece and destination"></div></div><div class="material-row" id="material-bottom"><strong class="material-name" id="material-bottom-name">White</strong><div class="material-pieces" id="material-bottom-pieces" aria-label="Captured pieces"></div><strong class="material-advantage" id="material-bottom-advantage"></strong></div><div class="board-bottom"><nav aria-label="Downloads"><a class="primary" id="pgn-download" href="match.pgn" download>Download PGN ↓</a><a id="gif-download" href="match.gif" download hidden>Download GIF ↓</a><a id="transcript-download" href="transcript.jsonl" download>Download transcript ↓</a></nav><span id="updated"></span></div></section></div>
<aside class="side"><div class="side-content"><section class="panel controls" aria-label="Game controls"><div class="fields"><label>Game mode<select id="mode"><option value="watch">Watch API A vs API B</option><option value="human-a">Play against API A</option><option value="human-b">Play against API B</option></select></label><label>Your color<select id="human-color" disabled><option value="" disabled>—</option><option value="white">White</option><option value="black">Black</option></select></label></div><button class="primary" id="start" type="button">Start game</button><button id="new-game" type="button" disabled>New game</button><p class="control-message" id="control-message" role="status"></p></section>
<div class="players"><article class="player" id="player-0"><span class="label">White ○</span><h2 id="model-0">Model A</h2><p class="endpoint" id="api-0"></p></article><article class="player" id="player-1"><span class="label">Black ●</span><h2 id="model-1">Model B</h2><p class="endpoint" id="api-1"></p></article></div>
<section class="status" aria-live="polite"><h2 id="status">Waiting</h2><p id="notice">Only legal moves enter the game.</p><div class="stats"><div><strong id="plies">0</strong><span>Moves played · plies</span></div><div><strong id="retries">0</strong><span>Rejected attempts</span></div><div><strong id="elapsed">0:00</strong><span>Elapsed</span></div></div></section>
<form class="panel controls" id="human-form" hidden><div class="move-entry"><label>Your move (UCI or SAN)<input id="human-move" autocomplete="off" placeholder="e2e4 or Nf3" aria-label="Your move"></label><label>Promotion<select id="promotion"><option value="q">Queen</option><option value="r">Rook</option><option value="b">Bishop</option><option value="n">Knight</option></select></label></div><button class="primary" id="submit-move" type="submit">Play move</button><span class="subtitle">Drag a piece, or click it and its destination. Select promotion before moving.</span></form>
<section class="panel history-panel"><h2>Move history · SAN notation</h2><div class="scroll" id="move-scroll"><table><thead><tr><th scope="col">#</th><th scope="col">White</th><th scope="col">Black</th></tr></thead><tbody id="moves"></tbody></table></div></section>
<section class="panel reply-panel"><h2>Latest reply</h2><pre id="reply">No reply yet.</pre></section></div></aside></div>
<footer>Rejected attempts stay off the board. PGN and transcript are saved after each turn.</footer></main>
<img id="drag-piece" alt="" draggable="false" hidden>
<script>
const initialState = /*MATCH_STATE*/{};
const pieceImages = /*PIECE_IMAGES*/{};
const byId = id => document.getElementById(id);
const text = (id, value) => { byId(id).textContent = value; };
let state = initialState, lastBoard = '', squareOrientation = '', selected = '', busy = false, restartPending = false;
let preferredHumanColor = initialState.human_color || 'white';
let drag = null, suppressBoardClick = false;
let pendingMove = null, loadedBoardVersion = '', lastMaterial = '';
const isSession = () => location.protocol !== 'file:' && !location.pathname.startsWith('/games/');
const isLive = () => isSession() && state.control_enabled;
const asset = name => location.protocol === 'file:' || !state.game_id ? name : `/games/${state.game_id}/${name}`;
const humanReady = () => isLive() && state.awaiting_human && !busy && !restartPending && !pendingMove;
function clock() {
  if(!state.started) { text('elapsed','0:00'); return; }
  const seconds = Math.max(0, Math.floor(((state.running ? Date.now() : Date.parse(state.updated)) - Date.parse(state.started))/1000));
  text('elapsed', `${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`);
}
function renderSquares() {
  if(squareOrientation !== state.orientation) {
    const squares = document.createDocumentFragment();
    for(let row=0;row<8;row++) for(let col=0;col<8;col++) {
      const black = state.orientation === 'black';
      const square = 'abcdefgh'[black ? 7-col : col] + (black ? row+1 : 8-row);
      const button = document.createElement('button');
      button.type='button'; button.dataset.square=square; button.draggable=false; button.setAttribute('aria-label',square);
      button.previewImage=document.createElement('img');
      button.previewImage.className='square-preview'; button.previewImage.alt='';
      button.previewImage.draggable=false; button.previewImage.hidden=true; button.appendChild(button.previewImage);
      button.addEventListener('click',event => {
        if(drag) { if(event) event.preventDefault(); return; }
        if(suppressBoardClick && event && event.detail !== 0) {
          suppressBoardClick=false; event.preventDefault(); return;
        }
        chooseSquare(square);
      });
      button.addEventListener('pointerdown',event => beginDrag(event,square,button));
      button.addEventListener('pointermove',moveDrag);
      button.addEventListener('pointerup',endDrag);
      button.addEventListener('pointercancel',cancelDrag);
      button.addEventListener('lostpointercapture',cancelDrag);
      squares.appendChild(button);
    }
    byId('squares').replaceChildren(squares); squareOrientation=state.orientation;
  }
  byId('squares').querySelectorAll('button').forEach(button => {
    const square=button.dataset.square;
    button.disabled=!humanReady(); button.classList.toggle('selected',selected === square);
    button.classList.toggle('target',humanReady() && !!selected && (state.legal_moves || []).some(m=>m.startsWith(selected+square)));
    button.classList.toggle('movable',humanReady() && movable(square));
    const source=!!drag && drag.active && drag.source === square;
    button.classList.toggle('drag-source',source);
    button.classList.toggle('drop-target',!!drag && drag.active && drag.hover === square && !!moveForSquares(drag.source,square));
    const preview=!!pendingMove && Object.hasOwn(pendingMove.changes,square);
    button.style.backgroundColor=source || preview ? (('abcdefgh'.indexOf(square[0])+Number(square[1])-1)%2 ? '#e8e5d5' : '#799281') : '';
    button.previewImage.hidden=!preview || !pendingMove.changes[square];
    if(!button.previewImage.hidden) button.previewImage.src=pieceImages[pendingMove.changes[square]];
  });
}
function prepareMovePreview(move) {
  move=move.trim();
  if(!(state.legal_moves || []).includes(move)) return null;
  const from=move.slice(0,2), to=move.slice(2,4), piece=pieceAt(from);
  if(!piece) return null;
  const changes={[from]:'',[to]:move.length===5 ? (piece===piece.toUpperCase()?move[4].toUpperCase():move[4]) : piece};
  if(piece.toLowerCase()==='p' && from[0]!==to[0] && !pieceAt(to)) changes[to[0]+from[1]]='';
  if(piece.toLowerCase()==='k' && Math.abs(from.charCodeAt(0)-to.charCodeAt(0))===2) {
    const kingside=to[0]>from[0], rank=from[1];
    changes[(kingside?'h':'a')+rank]='';
    changes[(kingside?'f':'d')+rank]=piece==='K'?'R':'r';
  }
  return {gameId:state.game_id,ply:state.moves.length,move,changes,confirmed:false};
}
function finishMovePreview() {
  if(pendingMove && pendingMove.confirmed && loadedBoardVersion===lastBoard) pendingMove=null;
}
function renderMaterial() {
  const key=`${state.game_id}:${state.orientation}:${JSON.stringify(state.material)}`;
  if(key===lastMaterial) return;
  lastMaterial=key;
  const bottom=state.orientation==='black'?'black':'white';
  for(const slot of ['top','bottom']) {
    const color=slot==='bottom'?bottom:(bottom==='white'?'black':'white');
    const name=color==='white'?'White':'Black';
    const material=(state.material || {})[color] || {captured:[],advantage:0};
    text(`material-${slot}-name`,name);
    text(`material-${slot}-advantage`,material.advantage>0?`+${material.advantage}`:'');
    const pieces=document.createDocumentFragment();
    for(const symbol of material.captured) {
      const icon=document.createElement('img');
      icon.src=pieceImages[symbol]; icon.draggable=false;
      icon.alt=`${symbol===symbol.toUpperCase()?'White':'Black'} ${{p:'pawn',n:'knight',b:'bishop',r:'rook',q:'queen',k:'king'}[symbol.toLowerCase()]}`;
      icon.title=icon.alt; pieces.appendChild(icon);
    }
    byId(`material-${slot}-pieces`).replaceChildren(pieces);
    byId(`material-${slot}`).title=`${name}: ${material.points ?? '—'} material points${material.advantage>0?`, ahead by ${material.advantage}`:''}`;
  }
}
function movable(square) {
  return (state.legal_moves || []).some(move=>move.startsWith(square));
}
function moveForSquares(from,to) {
  const choices=(state.legal_moves || []).filter(move=>move.startsWith(from+to));
  return choices.length === 1 ? choices[0] : choices.find(move=>move.endsWith(byId('promotion').value));
}
function pieceAt(square) {
  const row=state.fen.split(' ')[0].split('/')[8-Number(square[1])];
  let file=0;
  for(const piece of row) {
    if(/[1-8]/.test(piece)) file+=Number(piece);
    else { if(file === 'abcdefgh'.indexOf(square[0])) return piece; file++; }
  }
  return '';
}
function squareAt(x,y) {
  const box=byId('squares').getBoundingClientRect();
  if(!box.width || !box.height || x<box.left || y<box.top || x>=box.right || y>=box.bottom) return '';
  const col=Math.floor((x-box.left)*8/box.width), row=Math.floor((y-box.top)*8/box.height);
  return state.orientation === 'black' ? 'abcdefgh'[7-col]+(row+1) : 'abcdefgh'[col]+(8-row);
}
function clearDrag() {
  const previous=drag;
  drag=null; byId('drag-piece').hidden=true;
  if(previous) {
    if(previous.active) suppressBoardClick=true;
    try {
      if(previous.button.hasPointerCapture(previous.id)) previous.button.releasePointerCapture(previous.id);
    } catch(_) {}
  }
}
function cancelDrag(event) {
  if(!drag || (event && event.pointerId !== undefined && event.pointerId !== drag.id)) return;
  clearDrag(); renderSquares();
}
function beginDrag(event,square,button) {
  if(event.isPrimary === false || (event.button !== undefined && event.button !== 0)) return;
  suppressBoardClick=false;
  if(drag || !humanReady() || !movable(square)) return;
  const piece=pieceAt(square);
  if(!pieceImages[piece]) return;
  drag={id:event.pointerId,source:square,button,piece,x:event.clientX,y:event.clientY,
        gameId:state.game_id,ply:state.moves.length,fen:state.fen,active:false,hover:''};
  try { button.setPointerCapture(event.pointerId); } catch(_) {}
}
function moveDrag(event) {
  if(!drag || event.pointerId !== drag.id) return;
  if(!humanReady()) { cancelDrag(); return; }
  if(!drag.active) {
    if(Math.hypot(event.clientX-drag.x,event.clientY-drag.y)<6) return;
    drag.active=true; selected=drag.source;
    const ghost=byId('drag-piece'), box=drag.button.getBoundingClientRect();
    ghost.src=pieceImages[drag.piece]; ghost.style.width=`${box.width}px`; ghost.style.height=`${box.height}px`;
    ghost.hidden=false;
  }
  event.preventDefault();
  byId('drag-piece').style.left=`${event.clientX}px`;
  byId('drag-piece').style.top=`${event.clientY}px`;
  drag.hover=squareAt(event.clientX,event.clientY);
  renderSquares();
}
function endDrag(event) {
  if(!drag || event.pointerId !== drag.id) return;
  const previous=drag, destination=squareAt(event.clientX,event.clientY);
  const valid=humanReady() && previous.gameId === state.game_id && previous.ply === state.moves.length && previous.fen === state.fen;
  clearDrag();
  if(!previous.active) return; // Let a normal pointer tap deliver its usual click.
  event.preventDefault();
  if(!valid) { renderSquares(); return; }
  selected=previous.source;
  const move=destination && moveForSquares(previous.source,destination);
  if(move) sendMove(move);
  else {
    if(destination && destination !== previous.source) text('control-message','That move is not legal. Choose a highlighted square.');
    renderSquares();
  }
}
function renderControls() {
  if(restartPending) pendingMove=null;
  const waiting=state.phase === 'waiting';
  const watching=byId('mode').value === 'watch', color=byId('human-color');
  if(watching) {
    if(color.value === 'white' || color.value === 'black') preferredHumanColor=color.value;
    color.value='';
  } else if(!color.value) color.value=preferredHumanColor;
  byId('mode').disabled=!isLive() || !waiting || busy;
  color.disabled=!isLive() || !waiting || busy || watching;
  byId('start').disabled=!isLive() || !waiting || busy;
  byId('new-game').disabled=!isSession() || !state.restart_enabled || busy || restartPending;
  text('start',waiting ? 'Start game' : state.running ? 'Game in progress' : 'Game finished');
  byId('human-form').hidden=state.phase !== 'playing' || state.mode === 'watch';
  ['human-move','promotion','submit-move'].forEach(id=>byId(id).disabled=!humanReady());
  if(!humanReady()) clearDrag();
  renderEvaluation();
  renderSquares();
}
function renderEvaluation() {
  const mode=state.phase === 'waiting' ? byId('mode').value : state.mode;
  const visible=mode === 'watch';
  byId('eval-panel').hidden=!visible;
  if(!visible) return;
  const evaluation=state.evaluation || {};
  const ready=evaluation.status === 'ready';
  const description=ready ? `Stockfish: ${evaluation.label}, from White's perspective` : (evaluation.message || 'Evaluation starts with the game.');
  text('eval-score',ready ? evaluation.label : '—');
  byId('eval-fill').style.height=`${ready ? evaluation.white_percent : 50}%`;
  byId('eval-track').classList.toggle('unavailable',!ready);
  byId('eval-track').setAttribute('aria-valuetext',description);
  byId('eval-track').title=description;
  if(ready) byId('eval-track').setAttribute('aria-valuenow',evaluation.white_percent);
  else byId('eval-track').removeAttribute('aria-valuenow');
}
function render(next) {
  if(state.updated && next.updated < state.updated) return;
  if(pendingMove) {
    if(pendingMove.gameId!==next.game_id) pendingMove=null;
    else if(next.moves.length>pendingMove.ply) {
      if(next.moves[pendingMove.ply].uci===pendingMove.move) pendingMove.confirmed=true;
      else pendingMove=null;
    } else if(!next.running) pendingMove=null;
  }
  if(drag && (drag.gameId !== next.game_id || drag.ply !== next.moves.length || drag.fen !== next.fen || !next.awaiting_human)) clearDrag();
  if(state.game_id !== next.game_id) {
    selected=''; restartPending=false; lastBoard='';
    byId('human-move').value=''; text('control-message','');
    byId('promotion').value='q';
    byId('mode').value=next.mode || 'watch';
    byId('human-color').value=next.human_color || 'white';
  }
  state = next;
  state.players.forEach((p,i) => {
    text(`api-${i}`, p.api); text(`model-${i}`, p.model || `Model ${i ? 'B' : 'A'}`);
    byId(`player-${i}`).classList.toggle('active',state.phase === 'playing' && state.running && state.turn === p.color);
  });
  text('turn',state.phase === 'waiting' ? 'Ready to start' : state.running ? `${state.turn} to move` : 'Match stopped');
  text('result',state.result === '*' ? `Ply ${state.moves.length}` : `Result ${state.result}`);
  text('status',state.status); text('notice',state.notice || (state.in_check ? `${state.turn} is in check.` : 'Only legal moves enter the game.'));
  text('plies',state.moves.length); text('retries',state.retries.reduce((a,b)=>a+b,0));
  text('reply',state.latest_reply || 'No reply yet.'); text('updated',new Date(state.updated).toLocaleTimeString());
  byId('gif-download').hidden=state.gif_status !== 'ready';
  byId('pgn-download').href=asset('match.pgn');
  byId('gif-download').href=asset('match.gif');
  byId('transcript-download').href=asset('transcript.jsonl');
  if(state.gif_status === 'failed') text('control-message',state.gif_error);
  renderMaterial();
  const boardVersion=`${state.game_id}-${state.moves.length}-${state.orientation}`;
  if(lastBoard !== boardVersion) {
    selected='';
    const image=byId('board');
    image.onload=async()=>{
      try { if(image.decode) await image.decode(); }
      catch(_) { if(lastBoard===boardVersion) lastBoard=''; return; }
      if(lastBoard!==boardVersion) return;
      loadedBoardVersion=boardVersion; finishMovePreview(); renderControls();
    };
    image.onerror=()=>{if(lastBoard===boardVersion) lastBoard='';};
    image.src = `${asset('board.svg')}?v=${boardVersion}`;
    byId('board').alt = `Chessboard after ${state.moves.length} legal plies. ${state.turn} to move. FEN: ${state.fen}`;
    const rows = document.createDocumentFragment();
    state.moves.forEach(m => {
      let row = rows.lastChild;
      if(!row || row.dataset.number !== String(m.number)) {
        row = document.createElement('tr'); row.dataset.number = m.number;
        [String(m.number),'—','—'].forEach(value => { const td=document.createElement('td');td.textContent=value;row.appendChild(td); });
        rows.appendChild(row);
      }
      row.children[m.color === 'White' ? 1 : 2].textContent = m.san;
    });
    byId('moves').replaceChildren(rows); lastBoard = boardVersion;
    byId('move-scroll').scrollTop = byId('move-scroll').scrollHeight;
  }
  finishMovePreview();
  renderControls();
  clock();
}
async function refresh() {
  const response = await fetch(`state.json?t=${Date.now()}`,{cache:'no-store'});
  if(!response.ok) throw new Error('State unavailable');
  render(await response.json());
}
async function post(action,payload) {
  const response=await fetch(`/control/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...payload,token:state.control_token})});
  const result=await response.json();
  if(!response.ok) throw new Error(result.error || 'Action failed');
}
async function sendMove(move) {
  if(!humanReady()) return;
  const preview=prepareMovePreview(move);
  pendingMove=preview;
  busy=true; renderControls();
  try {
    await post('move',{move,ply:state.moves.length});
    byId('human-move').value=''; selected=''; text('control-message','Move submitted.');
    await refresh();
  } catch(error) {
    if(pendingMove===preview) pendingMove=null;
    text('control-message',error.message);
  }
  finally { busy=false; renderControls(); }
}
function chooseSquare(square) {
  if(!humanReady()) return;
  if(selected === square) selected='';
  else {
    const move=selected && moveForSquares(selected,square);
    if(move) { sendMove(move); return; }
    selected=(state.legal_moves || []).some(m=>m.startsWith(square)) ? square : '';
  }
  renderSquares();
}
byId('mode').value=state.mode || 'watch';
byId('human-color').value=state.human_color || 'white';
byId('mode').addEventListener('change',renderControls);
byId('start').addEventListener('click',async()=>{
  const settings={mode:byId('mode').value,human_color:byId('human-color').value || preferredHumanColor};
  busy=true; renderControls();
  try { await post('start',settings); await refresh(); text('control-message','Game started.'); }
  catch(error) { text('control-message',error.message); }
  finally { busy=false; renderControls(); }
});
byId('new-game').addEventListener('click',async()=>{
  busy=true; restartPending=true; renderControls();
  try {
    await post('restart',{});
    text('control-message','Saving this game and preparing a new board…');
    await refresh();
  } catch(error) { restartPending=false; text('control-message',error.message); }
  finally { busy=false; renderControls(); }
});
byId('human-form').addEventListener('submit',event=>{event.preventDefault();sendMove(byId('human-move').value);});
document.addEventListener('keydown',event=>{if(event.key === 'Escape' && drag){event.preventDefault();cancelDrag();}});
window.addEventListener('blur',()=>cancelDrag());
window.addEventListener('resize',()=>cancelDrag());
async function poll() {
  try {
    await refresh(); text('connection',state.phase === 'waiting' ? 'Ready · click Start game' : state.running ? 'Live game' : state.gif_status === 'pending' ? 'Saving animation…' : 'Match saved');
  } catch (_) { text('connection','Connection lost · last position shown'); }
  // Keep following the root page while the server switches game directories.
  if(isSession() || state.running || state.gif_status === 'pending' || state.session_active) setTimeout(poll,250);
}
render(initialState);
if(location.protocol === 'file:') text('connection','Saved match'); else poll();
setInterval(clock,1000);
</script></body></html>'''


def evaluation_score(score):
    """Display a White-perspective engine score; bar height is a visual scale."""
    mate = score.mate()
    if mate is not None:
        winning = score > chess.engine.Cp(0)
        return dict(status="ready", cp=None, mate=mate,
                    label=(("1–0" if winning else "0–1") if mate == 0 else
                           ("−" if mate < 0 else "") + f"M{abs(mate)}"),
                    white_percent=100 if winning else 0)
    cp = score.score()
    if cp is None:
        raise ValueError("Engine returned no position score")
    percent = max(1, min(99, 50 + 50 * math.tanh(cp / 400)))
    return dict(status="ready", cp=cp, mate=None, label=f"{cp / 100:+.2f}" if cp else "0.00",
                white_percent=round(percent, 1))


class StockfishEvaluator:
    def __init__(self, executable=None, seconds=0.1):
        self.engine = None
        self.seconds = seconds
        executable = executable or shutil.which("stockfish")
        if not executable and Path("/usr/games/stockfish").is_file():
            executable = "/usr/games/stockfish"
        if not executable:
            raise RuntimeError("Install Stockfish on the laptop: sudo apt install stockfish")
        try:
            self.engine = chess.engine.SimpleEngine.popen_uci([str(Path(executable).expanduser())], timeout=5)
            self.engine.configure({"Threads": 1, "Hash": 32})
        except BaseException:
            self.close()
            raise

    def evaluate(self, board, claim_draws=True):
        outcome = board.outcome(claim_draw=claim_draws)
        if outcome:
            if outcome.winner is None:
                return dict(status="ready", cp=0, mate=None, label="½–½", white_percent=50)
            return dict(status="ready", cp=None, mate=0,
                        label="1–0" if outcome.winner else "0–1",
                        white_percent=100 if outcome.winner else 0)
        info = self.engine.analyse(board.copy(stack=True), chess.engine.Limit(time=self.seconds),
                                   info=chess.engine.INFO_SCORE | chess.engine.INFO_BASIC)
        result = evaluation_score(info["score"].pov(chess.WHITE))
        result["depth"] = info.get("depth")
        return result

    def close(self):
        if self.engine is not None:
            try:
                self.engine.quit()
            except (chess.engine.EngineError, OSError, TimeoutError, RuntimeError):
                try:
                    self.engine.close()
                except (OSError, RuntimeError):
                    pass
            finally:
                self.engine = None


class Match:
    def __init__(self, directory, initial_fen, urls):
        self.board = valid_board(initial_fen)
        self.initial_fen = self.board.fen()
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=False)
        self.game = chess.pgn.Game()
        self.game.setup(self.board)
        self.game.headers.update(Event="Two model APIs", Date=datetime.now().strftime("%Y.%m.%d"))
        self.node = self.game
        self.evaluator = None
        self.claim_draws = True
        self.state = dict(players=[dict(color=c, api=u, model="") for c, u in zip(("White", "Black"), urls)],
                          running=True, status="Starting", notice="", latest_reply="", moves=[],
                          retries=[0, 0], result="*", started=now(), phase="playing",
                          awaiting_human=False, human_color=None, control_enabled=False,
                          mode="watch", gif_status="pending", gif_error="",
                          game_id=secrets.token_urlsafe(12), session_active=False, restart_enabled=False,
                          evaluation=dict(status="pending", message="Evaluation starts with the game."))
        self.transcript = (self.directory / "transcript.jsonl").open("x", encoding="utf-8")
        self.save()

    def event(self, kind, **data):
        self.transcript.write(json.dumps(dict(time=now(), event=kind, **data), ensure_ascii=True) + "\n")
        self.transcript.flush()

    def write(self, name, content):
        target = self.directory / name
        temporary = target.with_suffix(target.suffix + ".tmp")
        temporary.write_text(content, encoding="utf-8")
        temporary.replace(target)

    def save(self):
        board = self.board
        self.state.update(fen=board.fen(), turn="White" if board.turn else "Black",
                          in_check=board.is_check(), updated=now(), result=self.game.headers["Result"],
                          material=material_summary(board),
                          orientation="black" if self.state.get("human_color") == "black" else "white",
                          legal_moves=sorted(m.uci() for m in board.legal_moves)
                          if self.state["awaiting_human"] else [])
        self.write("board.svg", self.render_svg(board))
        self.write("match.pgn", str(self.game) + "\n\n")
        state = json.dumps(self.state, ensure_ascii=True)
        html = HTML.replace("/*PIECE_IMAGES*/{}", json.dumps(PIECE_IMAGES), 1)
        self.write("index.html", html.replace("/*MATCH_STATE*/{}", state.replace("<", "\\u003c"), 1))
        self.write("state.json", state)

    def render_svg(self, board, size=600):
        return chess.svg.board(board, lastmove=board.peek() if board.move_stack else None,
                               check=board.king(board.turn) if board.is_check() else None, size=size,
                               orientation=self.state["orientation"] == "white",
                               colors={"square light": "#e8e5d5", "square dark": "#799281"})

    def save_gif(self, renderer, interval=1.0):
        """Render the initial board and accepted plies once, after play stops."""
        target = self.directory / "match.gif"
        moves = list(self.board.move_stack)
        board = self.board.root()
        with TemporaryDirectory(prefix=".gif-", dir=self.directory) as temporary:
            frames = []
            for index in range(len(moves) + 1):
                frame = Path(temporary) / f"{index:05d}.svg"
                frame.write_text(self.render_svg(board, size=480), encoding="utf-8")
                frames.append(str(frame.with_suffix(".png").resolve()))
                if index < len(moves):
                    board.push(moves[index])
            output = Path(temporary) / "match.gif"
            helper = Path(__file__).resolve().with_name("render_chess_frames.py")
            # Use a system-Python subprocess so Conda's GLib cannot shadow librsvg.
            raster_environment = dict(os.environ)
            for name in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH"):
                raster_environment.pop(name, None)
            command = [renderer, "-delay", str(max(100, math.ceil(interval * 100))),
                       "-loop", "0", "-dispose", "None", *frames,
                       "-background", "#f6f4ec", "-alpha", "remove", "-alpha", "off",
                       "+dither", "-colors", "256", str(output.resolve())]
            try:
                subprocess.run(["/usr/bin/python3", str(helper), str(Path(temporary).resolve())],
                               check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                               text=True, timeout=300, env=raster_environment)
                subprocess.run(command, check=True, stdout=subprocess.DEVNULL,
                               stderr=subprocess.PIPE, text=True, timeout=300)
            except subprocess.CalledProcessError as error:
                raise RuntimeError(f"GIF export failed: {(error.stderr or str(error))[-2000:].strip()}") from error
            except subprocess.TimeoutExpired as error:
                raise RuntimeError("GIF export exceeded five minutes") from error
            output.replace(target)
        self.state.update(gif_status="ready", gif_error="")
        self.event("gif_saved", file="match.gif", frames=len(moves) + 1)
        self.save()
        return target

    def accept(self, move):
        if move not in self.board.legal_moves:
            raise ValueError("Cannot accept an illegal move")
        san = self.board.san(move)
        entry = dict(san=san, uci=move.uci(), number=self.board.fullmove_number,
                     color="White" if self.board.turn else "Black")
        self.board.push(move)
        self.node = self.node.add_variation(move)
        self.state["moves"].append(entry)
        self.state.update(notice=f"Accepted {entry['color']}: {san}", status="Move accepted")
        self.event("accepted", **entry, fen=self.board.fen())
        self.update_evaluation()
        self.save()
        print(f"{entry['number']}{'.' if entry['color'] == 'White' else '...'} {san}", flush=True)

    def finish(self, status, result="*", reason=""):
        self.game.headers.update(Result=result, Termination=reason or status)
        self.state.update(running=False, status=status, notice=reason, phase="finished",
                          awaiting_human=False, control_enabled=False,
                          restart_enabled=self.state["session_active"])
        self.event("finished", status=status, result=result, reason=reason)
        self.save()

    def configure_evaluation(self, args):
        self.close_evaluation()
        self.claim_draws = args.claim_draws
        if args.mode != "watch":
            self.state["evaluation"] = dict(status="disabled")
        elif getattr(args, "no_eval", False):
            self.state["evaluation"] = dict(status="unavailable", message="Evaluation disabled.")
        else:
            try:
                self.evaluator = StockfishEvaluator(getattr(args, "stockfish", None), getattr(args, "eval_time", 0.1))
                self.update_evaluation()
            except (chess.engine.EngineError, OSError, RuntimeError, TimeoutError, ValueError) as error:
                self.evaluation_unavailable(error)
        self.save()

    def update_evaluation(self):
        if self.evaluator is None:
            return
        try:
            self.state["evaluation"] = self.evaluator.evaluate(self.board, self.claim_draws)
            self.event("evaluation", ply=len(self.board.move_stack), **self.state["evaluation"])
        except (chess.engine.EngineError, OSError, RuntimeError, TimeoutError, ValueError, KeyError) as error:
            self.evaluation_unavailable(error)

    def evaluation_unavailable(self, error):
        self.close_evaluation()
        self.state["evaluation"] = dict(status="unavailable", message=str(error))
        self.event("evaluation_unavailable", reason=str(error))
        print(f"Evaluation unavailable: {error}", file=sys.stderr, flush=True)

    def close_evaluation(self):
        if self.evaluator is not None:
            self.evaluator.close()
            self.evaluator = None


def move_payload(match, args, rejected):
    board = match.board
    return dict(initial_fen=match.initial_fen, history=[m.uci() for m in board.move_stack],
                fen=board.fen(), result=result_token(args.condition, board),
                white_elo=args.white_elo, black_elo=args.black_elo, excluded_moves=list(rejected),
                temperature=args.temperature)


class ControlError(ValueError):
    def __init__(self, message, status=409):
        super().__init__(message)
        self.status = status


class RestartRequested(Exception):
    pass


class MatchControls:
    """Browser requests enqueue actions; only the referee changes the game."""
    def __init__(self):
        self.condition = Condition()
        self.token = secrets.token_urlsafe(24)
        self.settings = None
        self.position = None
        self.pending = None
        self.closed = False
        self.finished = False
        self.restart_requested = False

    def start(self, mode, human_color):
        with self.condition:
            if self.closed or self.finished or self.settings is not None:
                raise ControlError("This match has already started or ended")
            if mode not in ("watch", "human-a", "human-b") or human_color not in ("white", "black"):
                raise ControlError("Choose a game mode and White or Black", 400)
            self.settings = dict(mode=mode, human_color=human_color)
            self.condition.notify_all()

    def wait_for_start(self):
        with self.condition:
            while self.settings is None and not self.closed:
                self.condition.wait(0.25)
            if self.closed:
                raise RuntimeError("Match controls closed")
            return dict(self.settings)

    def begin_human_turn(self, board):
        with self.condition:
            self.check_restart()
            self.position = (board.copy(stack=False), len(board.move_stack))
            self.pending = None

    def submit_move(self, reply, ply):
        with self.condition:
            if (self.closed or self.finished or self.restart_requested
                    or self.position is None or self.pending is not None):
                raise ControlError("It is not waiting for your move; refresh the board")
            board, expected_ply = self.position
            if type(ply) is not int or ply != expected_ply:
                raise ControlError("The position has changed; refresh before moving")
            try:
                move = parse_move(board, reply)
            except ValueError as error:
                raise ControlError(str(error), 400) from error
            self.pending = move
            self.condition.notify_all()

    def wait_for_move(self):
        with self.condition:
            while self.pending is None and not self.closed and not self.restart_requested:
                self.condition.wait(0.25)
            self.check_restart()
            if self.closed:
                raise RuntimeError("Match controls closed")
            move = self.pending
            self.pending, self.position = None, None
            return move

    def check_restart(self):
        with self.condition:
            if self.restart_requested:
                raise RestartRequested()

    def request_restart(self):
        with self.condition:
            if self.closed or self.restart_requested or (self.settings is None and not self.finished):
                raise ControlError("This game is not ready for a new-game request")
            self.restart_requested = True
            self.position, self.pending = None, None
            self.condition.notify_all()

    def wait_for_restart(self):
        with self.condition:
            while not self.restart_requested and not self.closed:
                self.condition.wait(0.25)
            if self.closed:
                raise RuntimeError("Match controls closed")

    def end_game(self):
        with self.condition:
            self.finished = True
            self.position, self.pending = None, None
            self.condition.notify_all()

    def close(self):
        with self.condition:
            self.closed = True
            self.position = None
            self.condition.notify_all()


class MovePacer:
    def __init__(self, interval, controls=None):
        self.interval = interval
        self.previous = time.monotonic()
        self.controls = controls

    def accept(self, match, move):
        if self.controls is None:
            remaining = self.interval - (time.monotonic() - self.previous)
            if remaining > 0:
                time.sleep(remaining)
            match.accept(move)
        else:
            with self.controls.condition:
                while True:
                    self.controls.check_restart()
                    remaining = self.interval - (time.monotonic() - self.previous)
                    if remaining <= 0:
                        break
                    self.controls.condition.wait(remaining)
                # Serialize the final check and board update against restart clicks.
                match.accept(move)
        self.previous = time.monotonic()


def player_settings(args):
    urls = [args.api_a.rstrip("/"), args.api_b.rstrip("/")]
    protocols = [args.protocol_a, args.protocol_b]
    models = [args.model_a, args.model_b]
    mode = getattr(args, "mode", "watch")
    if mode == "watch":
        if urls[0] == urls[1]:
            raise ValueError("Supply two different API URLs for an API-vs-API match")
        return urls, protocols, models
    api_index = 0 if mode == "human-a" else 1
    human_index = 0 if args.human_color == "white" else 1
    return (["Human", urls[api_index]] if human_index == 0 else [urls[api_index], "Human"],
            ["human", protocols[api_index]] if human_index == 0 else [protocols[api_index], "human"],
            ["Human", models[api_index]] if human_index == 0 else [models[api_index], "Human"])


def play(match, args, request=request_json, controls=None):
    urls, protocols, models = player_settings(args)
    if "human" in protocols and controls is None:
        raise ValueError("Human play needs the browser controls")
    if "chessllama" in protocols:
        if match.initial_fen != chess.STARTING_FEN:
            raise ValueError("Chess Llama requires a complete game from the standard starting position")
        if args.condition == "draw":
            raise ValueError("Chess Llama has no draw conditioning token; use mover-wins, white-wins or black-wins")
    match.state.update(mode=getattr(args, "mode", "watch"),
                       human_color=getattr(args, "human_color", "white") if "human" in protocols else None)
    match.game.headers["Event"] = "Human vs model API" if "human" in protocols else "Two model APIs"
    for index in range(2):
        if protocols[index] != "human" and models[index] is None:
            models[index] = request(urls[index] + "/models", timeout=args.timeout)["data"][0]["id"]
        match.state["players"][index].update(model=models[index], api=urls[index])
        match.game.headers["White" if index == 0 else "Black"] = models[index]
    match.event("configuration", apis=urls, protocols=protocols, models=models,
                initial_fen=match.initial_fen, condition=args.condition,
                white_elo=args.white_elo, black_elo=args.black_elo, claim_draws=args.claim_draws,
                max_attempts=args.max_attempts, max_plies=args.max_plies, timeout=args.timeout,
                temperature=args.temperature, mode=match.state["mode"],
                human_color=match.state["human_color"], move_delay=getattr(args, "move_delay", 1.0))
    match.save()
    pacer = MovePacer(getattr(args, "move_delay", 1.0), controls)
    while True:
        if controls is not None:
            controls.check_restart()
        # Check before asking and after every accepted move, including the last
        # allowed ply. Claimable draws are an explicit, configurable match policy.
        outcome = match.board.outcome(claim_draw=args.claim_draws)
        if outcome:
            reason = outcome.termination.name.lower().replace("_", " ")
            match.finish("Game over", outcome.result(), reason)
            print(f"Game over: {outcome.result()} ({reason})", flush=True)
            return 0
        if args.max_plies and len(match.board.move_stack) >= args.max_plies:
            match.finish("Ply limit reached", reason="Ply limit reached; game unfinished")
            return 0
        index = 0 if match.board.turn else 1
        if "chessllama" in protocols and len(match.board.move_stack) + 1 > 256:
            match.finish("Model context exhausted", reason="Chess Llama's full move history exceeds 256 tokens; game unfinished")
            return 0
        color = "White" if index == 0 else "Black"
        if protocols[index] == "human":
            controls.begin_human_turn(match.board)
            match.state.update(status=f"Your turn ({color})", awaiting_human=True,
                               notice="Drag a piece, click a piece and destination, or enter a UCI/SAN move.")
            match.save()
            move = controls.wait_for_move()
            match.state.update(awaiting_human=False, latest_reply=f"{color} (Human): {move.uci()}")
            match.event("human_move", color=color, move=move.uci())
            match.save()
            pacer.accept(match, move)
            continue
        rejected, feedback, attempts = [], "", []
        for attempt in range(1, args.max_attempts + 1):
            match.state["status"] = f"{color} {'retrying' if attempt > 1 else 'choosing a move'}"
            match.save()
            payload = move_payload(match, args, rejected)
            if protocols[index] in ("board", "chessllama"):
                endpoint = "/chess/move"
            else:
                # Rebuild a complete current position each turn instead of
                # letting an unbounded chat history crowd it out of context.
                messages = chat_messages(match, protocols[index], payload["history"], attempts)
                payload = dict(model=models[index], messages=messages,
                               max_tokens=args.max_tokens, stream=False, temperature=args.temperature)
                endpoint = "/chat/completions"
            match.event("request", color=color, attempt=attempt, payload=payload)
            response = request(urls[index] + endpoint, payload, timeout=args.timeout)
            if controls is not None:
                controls.check_restart()  # Do not apply an old game's in-flight reply.
            if not isinstance(response, dict):
                raise ValueError("API response must be a JSON object")
            native = protocols[index] in ("board", "chessllama")
            reply = response.get("move") if native else response["choices"][0]["message"]["content"]
            match.event("response", color=color, attempt=attempt, response=response)
            match.state["latest_reply"] = f"{color}: {reply}"
            try:
                if not native and response["choices"][0].get("finish_reason") == "length":
                    raise ValueError("Response reached its token limit; increase --max-tokens")
                parser = parse_qwen3_move if protocols[index] == "qwen3-chess" else parse_move
                move = parser(match.board, reply)
            except ValueError as error:
                match.state["retries"][index] += 1
                feedback = (f"Rejected: {error}. No move was played. It is still {color}'s turn.\n"
                            f"Unchanged FEN: {match.board.fen()}\nChoose exactly one legal UCI move: "
                            + " ".join(sorted(m.uci() for m in match.board.legal_moves)))
                attempts.append((reply if isinstance(reply, str) else "", feedback))
                if isinstance(reply, str):
                    rejected.append(reply.strip())
                match.state.update(status=f"{color} must retry", notice=feedback)
                match.event("rejected", color=color, reason=str(error))
                match.save()
                print(f"{color}, attempt {attempt}: {error}", flush=True)
                continue  # Same API, same position; no reply sent to the opponent.
            pacer.accept(match, move)
            break
        else:
            match.finish("Retry limit reached", reason=f"{color} failed {args.max_attempts} attempts; game unfinished")
            return 1


class ViewerSession:
    """Keep one server while switching its current game and retaining old files."""
    def __init__(self, match, controls):
        self.lock = Lock()
        self.games = {}
        self.install(match, controls)

    def install(self, match, controls):
        with self.lock:
            self.directory, self.controls = match.directory, controls
            self.games[match.state["game_id"]] = match.directory

    def current(self):
        with self.lock:
            return self.directory, self.controls

    def archive(self, game_id):
        with self.lock:
            return self.games.get(game_id)


class ViewerHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, controls=None, session=None, **kwargs):
        self.session = session
        if session is not None:
            directory, controls = session.current()
            kwargs["directory"] = str(directory.resolve())
        self.controls = controls
        super().__init__(*args, **kwargs)

    def log_message(self, *args):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_GET(self):
        if self.route_game_file():
            super().do_GET()

    def do_HEAD(self):
        if self.route_game_file():
            super().do_HEAD()

    def route_game_file(self):
        if self.path.startswith("/games/"):
            parts = urlsplit(self.path).path.split("/")
            allowed = {"index.html", "state.json", "board.svg", "match.pgn", "match.gif", "transcript.jsonl"}
            directory = (self.session.archive(parts[2]) if self.session is not None
                         and len(parts) == 4 and parts[3] in allowed else None)
            if directory is None:
                self.send_error(404, "Unknown game or file")
                return False
            self.directory = str(directory.resolve())
            self.path = "/" + parts[3]
        return True

    def do_POST(self):
        status, response = 200, {"ok": True}
        try:
            if self.path not in ("/control/start", "/control/move", "/control/restart") or self.controls is None:
                raise ControlError("Unknown control endpoint", 404)
            self.connection.settimeout(30)
            if self.headers.get("Content-Type", "").split(";", 1)[0] != "application/json":
                raise ControlError("Send application/json", 400)
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 8192:
                raise ControlError("Control request must be 1..8192 bytes", 400)
            payload = json.loads(self.rfile.read(length))
            if not isinstance(payload, dict):
                raise ControlError("Request must be a JSON object", 400)
            token = payload.get("token")
            if not isinstance(token, str) or not secrets.compare_digest(token, self.controls.token):
                raise ControlError("This page belongs to another match; reload it", 403)
            if self.path == "/control/start":
                self.controls.start(payload.get("mode"), payload.get("human_color"))
            elif self.path == "/control/restart":
                self.controls.request_restart()
            else:
                self.controls.submit_move(payload.get("move"), payload.get("ply"))
        except (ValueError, TypeError, OSError) as error:
            status, response = getattr(error, "status", 400), {"error": str(error)}
        body = json.dumps(response).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def prepare_match(args, directory):
    urls = [args.api_a.rstrip("/"), args.api_b.rstrip("/")]
    match = Match(directory, args.fen, urls)
    controls = None if args.no_web else MatchControls()
    if controls is not None:
        match.state.update(phase="waiting", started=None, status="Ready to start",
                           notice="Choose a mode and click Start game.", control_enabled=True,
                           control_token=controls.token, mode=args.mode, human_color=args.human_color,
                           session_active=True)
        match.save()
    print(f"Match files: {match.directory.resolve()}", flush=True)
    return match, controls


def finish_gif(match, renderer, interval, code):
    try:
        print("Saving match.gif…", flush=True)
        path = match.save_gif(renderer, interval)
        print(f"GIF saved: {path.resolve()}", flush=True)
    except (OSError, RuntimeError, KeyboardInterrupt) as error:
        message = "GIF export interrupted" if isinstance(error, KeyboardInterrupt) else str(error)
        match.state.update(gif_status="failed", gif_error=message)
        match.event("gif_failed", reason=message)
        match.save()
        print(f"{message}. PGN, SVG, and transcript remain saved.", file=sys.stderr, flush=True)
        if code == 0:
            code = 130 if isinstance(error, KeyboardInterrupt) else 1
    return code


def new_match_directory(parent):
    return parent / ("chess-match-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
                     + "-" + secrets.token_hex(3))


def run_match(args):
    renderer = gif_renderer()
    directory = args.output or new_match_directory(Path.cwd())
    match, controls = prepare_match(args, directory)
    session = ViewerSession(match, controls) if controls is not None else None
    server, thread, code = None, None, 0
    try:
        if session is not None:
            server = ThreadingHTTPServer((args.web_host, args.web_port),
                                         partial(ViewerHandler, directory=str(match.directory.resolve()),
                                                 controls=controls, session=session))
            thread = Thread(target=server.serve_forever, daemon=True)
            thread.start()
            host = "127.0.0.1" if args.web_host == "0.0.0.0" else args.web_host
            print(f"Live board: http://{host}:{server.server_port}/", flush=True)
            if args.web_host == "0.0.0.0":
                print(f"From another machine: http://<referee-IP>:{server.server_port}/", flush=True)
        while True:
            try:
                if controls is not None:
                    print("Waiting for Start game in the browser.", flush=True)
                    settings = controls.wait_for_start()
                    args.mode, args.human_color = settings["mode"], settings["human_color"]
                match.state.update(phase="playing", started=now(), status="Starting", notice="",
                                   restart_enabled=controls is not None, mode=args.mode,
                                   human_color=args.human_color if args.mode != "watch" else None)
                match.event("started", mode=args.mode, human_color=args.human_color)
                match.save()
                match.configure_evaluation(args)
                code = play(match, args, controls=controls)
            except RestartRequested:
                match.finish("New game requested", reason="New game requested; game unfinished")
                code = 0
            except KeyboardInterrupt:
                match.finish("Interrupted", reason="Interrupted; game unfinished")
                code = 130
            except (OSError, URLError, ValueError, KeyError, IndexError, TypeError, RuntimeError) as error:
                match.finish("Error", reason=str(error))
                print(f"Match stopped: {error}", file=sys.stderr)
                code = 1
            if controls is not None:
                controls.end_game()
            match.close_evaluation()
            code = finish_gif(match, renderer, args.move_delay, code)
            if controls is None:
                break
            print("Match saved. Click New game in the page, or press Ctrl+C to close the viewer.", flush=True)
            try:
                controls.wait_for_restart()
            except KeyboardInterrupt:
                break
            match.event("restart_requested")
            controls.close()
            match.state.update(session_active=False, restart_enabled=False)
            match.save()
            match.transcript.close()
            match, controls = prepare_match(args, new_match_directory(match.directory.parent))
            session.install(match, controls)
    except (OSError, RuntimeError) as error:
        if not match.transcript.closed and match.state["running"]:
            match.finish("Error", reason=str(error))
            finish_gif(match, renderer, args.move_delay, 1)
        print(f"Viewer stopped: {error}", file=sys.stderr, flush=True)
        code = 1
    finally:
        match.close_evaluation()
        if controls is not None:
            controls.close()
        if not match.transcript.closed:
            match.state.update(session_active=False, restart_enabled=False, control_enabled=False)
            match.save()
            match.transcript.close()
        if server is not None:
            try:
                if thread is not None and thread.is_alive():
                    server.shutdown()
            finally:
                server.server_close()
                if thread is not None:
                    thread.join()
    return code


def gif_renderer():
    renderer = shutil.which("magick") or shutil.which("convert")
    if renderer is None:
        raise RuntimeError("GIF export needs ImageMagick on the referee laptop. "
                           "On Debian/Ubuntu: sudo apt install imagemagick")
    return renderer


def positive(value):
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError("must be positive")
    return number


def port(value):
    number = int(value)
    if not 0 <= number <= 65535:
        raise argparse.ArgumentTypeError("must be 0..65535 (0 chooses a free port)")
    return number


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    api = commands.add_parser("serve", help="Serve the native board model (no Distributed Llama conversion)")
    api.add_argument("--model-dir", type=Path, required=True)
    api.add_argument("--model-code", type=Path, required=True, help="Publisher's downloaded model.py")
    api.add_argument("--size", choices=("30M", "16M"), default="30M")
    api.add_argument("--host", default="127.0.0.1")
    api.add_argument("--port", type=port, default=9998)
    api.add_argument("--threads", type=positive, default=4)
    game = commands.add_parser("match", help="Referee two independently running APIs and show a live board")
    game.add_argument("--api-a", default="http://10.0.0.1:9998/v1", help="White API base, including /v1")
    game.add_argument("--api-b", default="http://10.0.0.3:9998/v1", help="Black API base, including /v1")
    game.add_argument("--mode", choices=("watch", "human-a", "human-b"), default="watch",
                      help="Initial browser selection: watch both APIs, or play API A/B")
    game.add_argument("--human-color", choices=("white", "black"), default="white",
                      help="Initial browser color selection for human play")
    game.add_argument("--move-delay", type=float, default=1.0,
                      help="Minimum seconds between accepted moves, at least 1 (default: 1)")
    game.add_argument("--stockfish", help="Stockfish executable for watch-mode evaluations; auto-detected by default")
    game.add_argument("--eval-time", type=float, default=0.1,
                      help="Stockfish seconds per position in watch mode (default: 0.1)")
    game.add_argument("--no-eval", action="store_true", help="Disable watch-mode Stockfish evaluation")
    for side in ("a", "b"):
        game.add_argument(f"--protocol-{side}", choices=("board", "chat", "qwen3-chess", "chessllama"), default="board",
                          help="qwen3-chess uses the chess-sft-6k square/piece prompt and tagged moves")
        game.add_argument(f"--model-{side}", help="Model ID; omit to discover via GET /models")
    game.add_argument("--white-elo", type=int, choices=ELOS, default=2400)
    game.add_argument("--black-elo", type=int, choices=ELOS, default=2400)
    game.add_argument("--condition", choices=RESULTS, default="mover-wins", help="Native board-model result conditioning")
    game.add_argument("--fen", default=chess.STARTING_FEN, help="Optional starting position (no earlier history)")
    game.add_argument("--max-attempts", type=positive, default=5, help="Attempts per turn before stopping unfinished")
    game.add_argument("--max-plies", type=int, default=512, help="Accepted half-move limit; 0 means unlimited")
    game.add_argument("--max-tokens", type=positive, default=32, help="Chat API response budget")
    game.add_argument("--temperature", type=float, default=0.0,
                      help="Chat/Chess Llama sampling temperature; 0 is greedy")
    game.add_argument("--timeout", type=positive, default=180, help="Seconds per API request")
    game.add_argument("--no-claim-draws", dest="claim_draws", action="store_false",
                      help="Wait for automatic draws instead of claiming threefold/fifty-move draws")
    game.add_argument("--output", type=Path, help="New match directory; refuses an existing directory")
    game.add_argument("--web-host", default="127.0.0.1")
    game.add_argument("--web-port", type=port, default=8000)
    game.add_argument("--no-web", action="store_true", help="Write artifacts without starting the viewer server")
    game.add_argument("--keep-web", action="store_true",
                      help="Compatibility flag; the web viewer now stays open for New game until Ctrl+C")
    args = parser.parse_args(argv)
    if args.command == "match" and args.max_plies < 0:
        parser.error("--max-plies must be zero or greater")
    if args.command == "match" and (not math.isfinite(args.temperature) or args.temperature < 0):
        parser.error("--temperature must be finite and zero or greater")
    if args.command == "match" and (not math.isfinite(args.move_delay) or args.move_delay < 1):
        parser.error("--move-delay must be finite and at least 1 second")
    if args.command == "match" and (not math.isfinite(args.eval_time) or not 0 < args.eval_time <= 5):
        parser.error("--eval-time must be finite and greater than zero, up to 5 seconds")
    if args.command == "match" and args.no_web and args.mode != "watch":
        parser.error("Human play requires the web viewer; omit --no-web")
    try:
        return serve(args) if args.command == "serve" else run_match(args)
    except KeyboardInterrupt:
        return 130
    except (ImportError, OSError, URLError, ValueError, KeyError, TypeError, RuntimeError) as error:
        print(f"Stopped: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
