"""Portable setup isolation, address handling, build compatibility and clean ZIPs."""
from contextlib import redirect_stdout
from io import StringIO
import json
from pathlib import Path
import shutil
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import zipfile

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import pi_chess as helper
import make_student_zip as release
import build_chessllama as builder


class PortableTests(unittest.TestCase):
    def test_addresses_use_separate_chess_port(self):
        self.assertEqual(helper.worker_address('10.1.0.2'), '10.1.0.2:10098')
        self.assertEqual(helper.worker_address('node02:10099'), 'node02:10099')
        self.assertEqual(helper.api_address('10.1.0.1'), 'http://10.1.0.1:10098/v1')
        self.assertEqual(helper.api_address('http://node03:9998/v1/'), 'http://node03:9998/v1')
        self.assertEqual(helper.worker_address('[::1]:10098'), '[::1]:10098')

    def test_invalid_addresses_are_rejected(self):
        for value in ['host:0', 'host:65536', 'host/path', 'user@host', 'a b', '']:
            with self.subTest(value=value), self.assertRaises(helper.argparse.ArgumentTypeError):
                helper.worker_address(value)
        for value in ['file:///tmp/example', 'http://host/api', 'http://u:p@host', 'http://host:0/v1']:
            with self.subTest(value=value), self.assertRaises(helper.argparse.ArgumentTypeError):
                helper.api_address(value)

    def test_unowned_private_directory_is_not_modified(self):
        with TemporaryDirectory() as directory:
            base = Path(directory)
            state = base / helper.STATE
            state.mkdir()
            (state / 'keep').write_text('untouched')
            with self.assertRaises(ValueError):
                helper.state_directory(create=True, base=base)
            self.assertEqual(list(state.iterdir()), [state / 'keep'])
            self.assertEqual((state / 'keep').read_text(), 'untouched')

    def test_private_directory_and_settings_are_local(self):
        with TemporaryDirectory() as directory:
            base = Path(directory)
            helper.state_directory(create=True, base=base)
            helper.save_settings({'root': {'worker': 'node02:10098'}}, base=base)
            self.assertEqual(helper.settings(base), {'root': {'worker': 'node02:10098'}})
            self.assertEqual(sorted(p.name for p in base.iterdir()), ['.pi-chess'])

    def test_private_directory_symlink_is_rejected(self):
        with TemporaryDirectory() as directory, TemporaryDirectory() as other:
            base = Path(directory)
            (base / helper.STATE).symlink_to(other, target_is_directory=True)
            with self.assertRaises(ValueError):
                helper.state_directory(create=True, base=base)
            self.assertEqual(list(Path(other).iterdir()), [])

    def test_venv_python_symlink_is_supported(self):
        with TemporaryDirectory() as directory:
            base = Path(directory)
            path = base / '.pi-chess/python-example/venv/bin/python'
            path.parent.mkdir(parents=True)
            path.symlink_to(sys.executable)
            self.assertEqual(helper.private_python({'python': path.relative_to(base).as_posix()}, base), path)

    def test_setup_paths_cannot_escape_private_folder(self):
        with TemporaryDirectory() as directory:
            base = Path(directory)
            for name in ['../python', '/usr/bin/python3', 'outside/python']:
                with self.subTest(name=name), self.assertRaises(ValueError):
                    helper.private_python({'python': name}, base)
            with self.assertRaises(ValueError):
                helper.local_path('runtime/src/dllama.cpp', base)

    def test_api_uses_saved_worker_and_private_native_backend(self):
        args = helper.parser().parse_args(['api'])
        values = dict(root=dict(binary='.pi-chess/root/example', worker='10.1.0.2:10098', port=10098, threads=4))
        with patch.object(helper, 'private_python', return_value=Path('/private/python')), patch.object(helper, 'local_path', return_value=Path('/private/backend')):
            command = helper.api_command(args, values)
        self.assertEqual(command[0], '/private/python')
        self.assertEqual(command[command.index('--workers') + 1], '10.1.0.2:10098')
        self.assertEqual(command[command.index('--backend') + 1], '/private/backend')
        self.assertNotIn('--chat-template', command)

    def test_solo_override_omits_worker_without_changing_settings(self):
        args = helper.parser().parse_args(['api', '--solo'])
        values = dict(root=dict(binary='.pi-chess/root/example', worker='node02:10098', port=10098, threads=4))
        with patch.object(helper, 'private_python', return_value=Path('/private/python')), patch.object(helper, 'local_path', return_value=Path('/private/backend')):
            command = helper.api_command(args, values)
        self.assertNotIn('--workers', command)
        self.assertEqual(values['root']['worker'], 'node02:10098')

    def test_worker_uses_its_private_build(self):
        args = helper.parser().parse_args(['worker', '--threads', '2'])
        with patch.object(helper, 'local_path', return_value=Path('/private/worker')):
            command = helper.worker_command(args, dict(worker=dict(binary='.pi-chess/worker', port=10098, threads=4)))
        self.assertEqual(command, ['/private/worker', 'worker', '--port', '10098', '--nthreads', '2'])

    def test_play_preserves_temperature_context_and_browser_gate(self):
        args = helper.parser().parse_args(['play', '--mode', 'human-b', '--human-color', 'black', '--temperature', '0'])
        values = dict(laptop=dict(api_a='http://a:10098/v1', api_b='http://b:10098/v1', temperature=0.7, web_port=8000))
        with patch.object(helper, 'private_python', return_value=Path('/private/python')):
            command = helper.play_command(args, values)
        self.assertEqual(command[command.index('--temperature') + 1], '0.0')
        self.assertEqual(command[command.index('--max-plies') + 1], '256')
        self.assertEqual(command[command.index('--mode') + 1], 'human-b')
        self.assertEqual(command[command.index('--protocol-b') + 1], 'chessllama')
        self.assertIn('--keep-web', command)
        self.assertNotIn('--no-web', command)

    def test_single_player_connectivity_check_contacts_only_selected_api(self):
        args = helper.parser().parse_args(['check', '--mode', 'human-a'])
        values = dict(laptop=dict(api_a='http://a/v1', api_b='http://b/v1'))
        with patch.object(helper, 'urlopen') as request:
            request.return_value.__enter__.return_value = StringIO('{"data":[{"id":"chess-llama-f32"}]}')
            with redirect_stdout(StringIO()):
                helper.check_apis(args, values)
        self.assertEqual(request.call_args.args, ('http://a/v1/models',))
        self.assertEqual(request.call_count, 1)

    def test_default_setup_is_memory_conservative(self):
        args = helper.parser().parse_args(['setup', 'worker'])
        self.assertEqual(args.jobs, 1)
        self.assertEqual(args.port, 10098)

    def test_python_installs_only_in_a_fresh_private_venv(self):
        with TemporaryDirectory() as directory:
            base = Path(directory)
            state = base / '.pi-chess';state.mkdir()
            values = {}
            with patch.object(helper, 'HERE', base), patch.object(helper, 'state_directory', return_value=state), patch.object(helper, 'run') as run:
                python = helper.ensure_python(values)
            venv_command, pip_command = [call.args[0] for call in run.call_args_list]
            self.assertIn('venv', venv_command)
            self.assertTrue(Path(venv_command[-1]).is_relative_to(state))
            self.assertEqual(pip_command[0], python)
            self.assertIn('--isolated', pip_command)
            self.assertIn('--no-cache-dir', pip_command)
            self.assertEqual(pip_command[-1], base / 'requirements.txt')
            self.assertNotIn('--user', pip_command)
            self.assertEqual(base / values['python'], python)

    def test_completed_environment_is_checked_without_reinstalling(self):
        values = {'python': '.pi-chess/python-existing/venv/bin/python'}
        with patch.object(helper, 'private_python', return_value=Path('/private/python')), patch.object(helper, 'run') as run:
            helper.ensure_python(values)
        self.assertEqual(run.call_count, 1)
        self.assertEqual(run.call_args.args[0][0:3], [Path('/private/python'), '-I', '-c'])

    def test_missing_venv_support_has_actionable_error(self):
        with TemporaryDirectory() as directory:
            with patch.object(helper, 'state_directory', return_value=Path(directory)), patch.object(helper, 'run', side_effect=helper.subprocess.CalledProcessError(1, ['venv'])):
                with self.assertRaisesRegex(ValueError, 'python3-venv'):
                    helper.ensure_python({})

    def test_launch_does_not_inherit_python_environment_overrides(self):
        with patch.dict(helper.os.environ, {'PYTHONHOME': '/other/python', 'PYTHONPATH': '/other/packages'}), patch.object(helper.os, 'chdir') as chdir, patch.object(helper.os, 'execv') as execute, redirect_stdout(StringIO()):
            helper.launch(['/private/python', '/bundle/chess_match.py'], cwd=Path('/bundle/games'))
            self.assertNotIn('PYTHONHOME', helper.os.environ)
            self.assertNotIn('PYTHONPATH', helper.os.environ)
            execute.assert_called_once_with('/private/python', ['/private/python', '/bundle/chess_match.py'])
            chdir.assert_called_once_with(Path('/bundle/games'))

    def test_snapshot_is_pinned_and_detects_modified_sources(self):
        with TemporaryDirectory() as directory:
            runtime = Path(directory) / 'runtime'
            shutil.copytree(BASE / 'runtime', runtime)
            self.assertEqual(builder.runtime_revision(runtime), builder.RUNTIME_COMMIT)
            (runtime / 'src/tokenizer.cpp').write_text('changed')
            with self.assertRaises(ValueError):
                builder.runtime_revision(runtime)

    def test_snapshot_rejects_unlisted_source(self):
        with TemporaryDirectory() as directory:
            runtime = Path(directory) / 'runtime'
            shutil.copytree(BASE / 'runtime', runtime)
            (runtime / 'src/extra.hpp').write_text('changed')
            with self.assertRaises(ValueError):
                builder.runtime_revision(runtime)

    def test_worker_build_reads_stock_source_and_writes_only_new_output(self):
        with TemporaryDirectory() as directory:
            output = Path(directory) / 'build'
            with patch.object(builder.subprocess, 'run') as run, patch.object(builder.shutil, 'which', return_value='/usr/bin/g++'), redirect_stdout(StringIO()):
                binary = builder.build(BASE / 'runtime', output, jobs=1, worker=True)
            self.assertEqual(binary.name, 'dllama-chess-worker')
            compiler_calls = [call.args[0] for call in run.call_args_list]
            self.assertTrue(any(str(BASE / 'runtime/src/dllama.cpp') in command for command in compiler_calls))
            self.assertTrue(all(str(BASE / 'chessllama_backend.cpp') not in command for command in compiler_calls))
            for command in compiler_calls:
                self.assertTrue(Path(command[command.index('-o') + 1]).is_relative_to(output))
            with self.assertRaises(FileExistsError):
                builder.build(BASE / 'runtime', output, jobs=1, worker=True)

    def fixture_bundle(self, base):
        runtime = base / 'runtime'
        runtime.mkdir()
        (runtime / 'UPSTREAM.json').write_text(json.dumps({'files': {'LICENSE': 'unused'}}))
        (runtime / 'LICENSE').write_text('upstream license')
        for name in release.FILES:
            path = base / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('fixture ' + name)
        release.refresh_manifest(base)

    def test_clean_zip_excludes_games_environments_settings_and_other_zips(self):
        with TemporaryDirectory() as directory:
            base = Path(directory) / 'bundle';base.mkdir()
            self.fixture_bundle(base)
            for name in ['games/secret.pgn', '.venv/bin/python', '.pi-chess/settings.json', 'chess-match-old/transcript.jsonl', 'unrelated.zip']:
                path = base / name;path.parent.mkdir(parents=True, exist_ok=True);path.write_text('private')
            output = Path(directory) / 'students.zip'
            with redirect_stdout(StringIO()):
                release.package(output, base)
            with zipfile.ZipFile(output) as archive:
                names = archive.namelist()
                self.assertEqual(set(names), {'pi-chess/' + name for name in release.release_files(base)} | {'pi-chess/SHA256SUMS'})
                self.assertIsNone(archive.testzip())
                self.assertTrue(all(not name.startswith('/') and '..' not in Path(name).parts for name in names))
            self.assertIn(helper.digest(output), output.with_name(output.name + '.sha256').read_text())
            with self.assertRaises(ValueError):
                release.package(output, base)

    def test_manifest_tampering_is_rejected(self):
        with TemporaryDirectory() as directory:
            base = Path(directory)
            self.fixture_bundle(base)
            (base / 'requirements.txt').write_text('tampered')
            with self.assertRaises(ValueError):
                helper.verify_bundle(base)

    def test_manifest_traversal_is_rejected(self):
        with TemporaryDirectory() as directory:
            base = Path(directory)
            (base / 'SHA256SUMS').write_text('0' * 64 + '  ../outside\n')
            with self.assertRaises(ValueError):
                helper.verify_bundle(base)


if __name__ == '__main__':
    unittest.main()
