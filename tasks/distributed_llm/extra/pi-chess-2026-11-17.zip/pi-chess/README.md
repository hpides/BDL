# Pi Chess — student setup

Play against Chess Llama or watch two models play, with inference distributed
across your Raspberry Pi cluster. This ZIP contains the converted model, the
live board, and all C++ sources needed for compatible roots and workers.
**No model conversion, PyTorch, Hugging Face account, or runtime patches are needed.**

Use a **Linux laptop** (Debian/Ubuntu recommended) and **four 64-bit Raspberry
Pis** with SSH/networking already working. Your existing Distributed Llama
installation can stay as it is. This add-on builds its own executables inside
its folder. Native Windows/macOS setup is not covered by this release.

## 1. Extract the ZIP into a fresh folder

Download the supplied `pi-chess-2026-11-17.zip` and its `.sha256` file into the
same Downloads folder. You need Python 3.9+ and `unzip` on these computers;
if missing, install `python3` and `unzip` with your package manager first.
On your laptop:

```bash
cd "$HOME/Downloads"
sha256sum -c pi-chess-2026-11-17.zip.sha256
unzip -n pi-chess-2026-11-17.zip -d "$HOME/pi-chess-lab"
cd "$HOME/pi-chess-lab/pi-chess"
python3 pi_chess.py verify
```

Choose a **new destination** if `~/pi-chess-lab` already exists. Extract on
each computer; do not copy an already configured folder or virtual environment
between computers. Builds target the CPU on which setup runs.

This guide uses these example addresses. Replace them with your own:

| Computer | Example IP | Runs |
| --- | --- | --- |
| Laptop | Can reach both roots | Browser, referee, optional Stockfish |
| Pi 1 | `10.0.0.1` | API A / inference root A |
| Pi 2 | `10.0.0.2` | Worker A |
| Pi 3 | `10.0.0.3` | API B / inference root B |
| Pi 4 | `10.0.0.4` | Worker B |

A player uses **one root plus one worker**, so two players use all four Pis.
The APIs can play either color. The model supports at most two inference
nodes per player; do not attach three workers to one root.

## 2. Copy the ZIP to the Pis

From the laptop's download folder, copy the **same ZIP** to each Pi. Change
`pi` below if your SSH username differs:

```bash
cd "$HOME/Downloads"
scp pi-chess-2026-11-17.zip pi@10.0.0.1:~/
scp pi-chess-2026-11-17.zip pi@10.0.0.2:~/
scp pi-chess-2026-11-17.zip pi@10.0.0.3:~/
scp pi-chess-2026-11-17.zip pi@10.0.0.4:~/
```

On **each Pi**, in an SSH terminal:

```bash
unzip -n "$HOME/pi-chess-2026-11-17.zip" -d "$HOME/pi-chess-lab"
cd "$HOME/pi-chess-lab/pi-chess"
python3 pi_chess.py verify
```

Use fresh extraction folders. `unzip -n` avoids overwriting existing files.
The full ZIP is used on every Pi to keep the instructions the same; workers
only use the runtime sources and their worker executable, not the model files.

## 3. One-time setup on each Pi

If needed, install the standard compiler/Python tools on the Pis:

```bash
sudo apt update
sudo apt install --no-install-recommends g++ python3 python3-venv unzip
```

Run the command for each Pi's role from its extracted `pi-chess` folder:

| Where | Setup command |
| --- | --- |
| Pi 1 / root A | `python3 pi_chess.py setup root --worker 10.0.0.2` |
| Pi 2 / worker A | `python3 pi_chess.py setup worker` |
| Pi 3 / root B | `python3 pi_chess.py setup root --worker 10.0.0.4` |
| Pi 4 / worker B | `python3 pi_chess.py setup worker` |

**Replace the worker IPs with yours.** Setup compiles locally, which can take
several minutes on a Pi. It uses one compiler job to limit memory use. A faster
Pi can use `--jobs 2`. Wait for `Setup complete` on each machine.

Root setup creates a private Python environment and installs the pinned
`chess==1.11.2` dependency. Worker setup does not install Python packages.
An internet connection is needed for the root/laptop pip install; the runtime
source and converted model are already included. Nothing is installed into
system Python or an existing Conda/venv environment.

All generated setup files stay under **`.pi-chess/`** in the extracted folder.
The helper does not run `sudo`, edit your existing runtime, change shell
startup files, stop other processes, or install services. Repeating setup
reuses a completed private build/environment. If a build failed, rerun setup;
incomplete builds are kept and a fresh build directory is used. Use
`--rebuild` to replace the selected build with a newly compiled copy while
keeping the earlier build files.

## 4. One-time laptop setup

On a Debian/Ubuntu **laptop**, install any missing dependencies. ImageMagick
and the SVG libraries provide GIF export; Stockfish provides the watch-mode
evaluation bar:

```bash
sudo apt update
sudo apt install --no-install-recommends python3 python3-venv imagemagick librsvg2-2 libcairo2 stockfish
```

Stockfish is optional: omit it if you do not want evaluation scores. The game
still runs and the watch-mode bar shows `—`. No engine is used for human games.

In the laptop's extracted folder:

```bash
cd "$HOME/pi-chess-lab/pi-chess"
python3 pi_chess.py setup laptop --api-a 10.0.0.1 --api-b 10.0.0.3
```

**Replace these two addresses with your API-root IPs.** They are saved, so you
do not need to enter them every time. Setup checks GIF dependencies and creates
a private environment inside this folder.

## 5. Start the cluster

Keep **one SSH terminal per Pi** open. In each, go to
`~/pi-chess-lab/pi-chess`.
If another model is already using these Pis, stop it with Ctrl+C first so
memory and CPU are available; keep its installation files in place.

First start both workers:

| Where | Command |
| --- | --- |
| Pi 2 | `python3 pi_chess.py worker` |
| Pi 4 | `python3 pi_chess.py worker` |

Then start both APIs:

| Where | Command |
| --- | --- |
| Pi 1 | `python3 pi_chess.py api` |
| Pi 3 | `python3 pi_chess.py api` |

Wait for **`Chess Llama API ready`** in each API terminal. The roots load the
model and connect to their saved worker addresses first.

This release uses **TCP port `10098`** for APIs and workers, keeping it separate
from the usual Distributed Llama port `9998`. Use the bundled launch commands
for both ends; a stock worker running on `9998` is not the worker these saved
settings point to. Keep ports reachable within your trusted cluster network.
The API has no authentication; do not expose it through an internet router.

## 6. Open the board and play

On the **laptop**:

```bash
cd "$HOME/pi-chess-lab/pi-chess"
python3 pi_chess.py check
python3 pi_chess.py play
```

Open **http://127.0.0.1:8000/** in your laptop browser.

1. Choose **Watch API A vs API B**, **Play against API A**, or **Play against API B**.
2. For a human game, choose White or Black.
3. Click **Start game**. No moves happen before this click.

Human moves support **dragging**, **clicking a piece then its destination**, or
entering SAN/UCI such as `Nf3` / `g1f3`. Choose the promotion piece before moving
a pawn onto its final rank. Moves are checked for legality; invalid model
replies are retried. The referee detects checkmate and draws, with a 256-ply
safety cap for this model's context window.

The page includes move history, captured-piece icons, material advantage, and
a watch-only Stockfish evaluation bar. Accepted moves are at least one second
apart. Temperature defaults to **0.7** so openings can vary. Legal human drops
stay at the destination while the accepted board refreshes.

Use **New game** in the page to play again without rerunning commands. Games
are saved in **`games/chess-match-.../`** with `board.svg`, `match.pgn`,
`transcript.jsonl`, and `state.json`. At game end or interruption, the referee
also saves **`match.gif`**. Download buttons are below the bottom material
counter. Wait for `GIF saved` before closing the referee terminal.

## After a reboot — only start, do not set up again

From `~/pi-chess-lab/pi-chess` on the appropriate computer:

1. Pi 2 and Pi 4: `python3 pi_chess.py worker`
2. Pi 1 and Pi 3: `python3 pi_chess.py api`
3. Laptop: `python3 pi_chess.py play`
4. Open http://127.0.0.1:8000/ and click **Start game**.

No compilation, pip install, environment activation, or model download is
needed again. Stop the laptop referee first with Ctrl+C, wait for any GIF
export, then stop APIs and workers with Ctrl+C. The add-on does not start
automatically at boot.

## Small changes and troubleshooting

- **Different IPs:** rerun `setup laptop --api-a NEW_ROOT_A --api-b NEW_ROOT_B`
  on the laptop, or `setup root --worker NEW_WORKER` on the affected root.
  Completed builds are reused. Restart the relevant process afterwards.
- **Connection refused:** leave the worker terminal running before starting
  its API, wait for `Chess Llama API ready`, then run `python3 pi_chess.py check`
  on the laptop. An unreachable worker can prevent its root from becoming ready.
- **Address already in use:** stop your earlier chess process with Ctrl+C.
  The helper never kills another process. For a different API/worker port,
  use `setup worker --port 10099`, `setup root --port 10099 --worker WORKER_IP:10099`,
  and full laptop URLs such as `setup laptop --api-a http://ROOT_A:10099/v1 --api-b http://ROOT_B:10099/v1`.
  Root and worker ports can also differ if the worker address names its actual port.
- **Laptop port 8000 busy:** `python3 pi_chess.py play --web-port 8001`, then open
  http://127.0.0.1:8001/.
- **Only two Pis:** set up both as roots, omit `--worker`, and run only the two
  APIs. Each model then runs on its root alone.
- **Only one model needed:** for human vs A, start root A and its worker only.
  Use `python3 pi_chess.py check --mode human-a` and
  `python3 pi_chess.py play --mode human-a`. Only API A is contacted when playing
  this mode. Either API can play either color.
- **Test a root without its worker:** `python3 pi_chess.py api --solo`.
- **Change variety:** `python3 pi_chess.py play --temperature 1.0`;
  `--temperature 0` chooses the highest-scoring legal move each time.
- **Compilation failed:** verify the ZIP, make sure this is a 64-bit Pi OS,
  install `g++` if missing, and retry setup with `--jobs 1`. For a new CPU or OS,
  extract a fresh ZIP and set up on that computer rather than copying a build.
- **Missing venv support:** install `python3-venv`, then rerun setup. Run setup
  as your normal user; do not use `sudo python3 ...`.
- **GIF dependency error:** install the laptop ImageMagick/librsvg/Cairo
  packages listed above. Stockfish is not required for GIFs.
- **Environment moved/copied:** extract and set up again at the final path.
  Python virtual environments are not portable; the ZIP itself is portable.

To remove the add-on, stop its foreground processes and remove its extracted
folder after copying any games you want to keep. Your existing Distributed
Llama installation is independent. Optional OS packages installed with `apt`
are system packages and remain until you choose to remove them.

## Source and scope

Model: [lazy-guy12/chess-llama](https://huggingface.co/lazy-guy12/chess-llama),
converted to native F32 (about 88 MiB). See the original [model card](MODEL_CARD.md),
[conversion provenance](PROVENANCE.json), and [numerical parity check](PARITY_CHECK.json).
The upstream card estimates an Elo of 1400; this cluster build has not been
independently Elo-rated. No additional model license is assigned by this bundle.

Runtime: [Distributed Llama v0.16.3](https://github.com/b4rtaz/distributed-llama/tree/96c661e6a45db59b0e0d161d364fb0a813bd8020),
commit `96c661e6a45db59b0e0d161d364fb0a813bd8020`, included as a pristine source
snapshot with its [MIT license](runtime/LICENSE). Runtime source hashes are in
`runtime/UPSTREAM.json`. Python dependencies are installed separately from
`requirements.txt`. The live board uses python-chess's SVG pieces.

[PORTABLE_VALIDATION.json](PORTABLE_VALIDATION.json) records release checks and
their limits. A real multi-Pi/network test remains part of following the setup
on your own cluster. See [MAINTAINER.md](MAINTAINER.md) to build a fresh ZIP.
