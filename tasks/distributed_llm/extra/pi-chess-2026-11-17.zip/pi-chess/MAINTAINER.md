# Maintaining the student ZIP

The source for this release is this `pi-chess` folder. The earlier
`chessllama-cluster` folder is a separate working installation and is not
modified by student setup or packaging.

Build a fresh archive from here:

```bash
python3 make_student_zip.py --output ../releases/pi-chess-2026-11-17.zip
```

After intentional source changes, run the tests, update
`PORTABLE_VALIDATION.json`, then recalculate the file manifest while building
under a new archive name:

```bash
python3 -m unittest discover -s tests -v
python3 make_student_zip.py --refresh-manifest --output ../releases/pi-chess-next.zip
```

The packager uses an **explicit file list** and the runtime's upstream manifest.
It excludes `.pi-chess`, virtual environments, compiled binaries, `games/`, old
match folders, personal settings, logs, Git metadata, and previous ZIPs.
It checks every included file, checks ZIP CRCs, and writes a sibling `.sha256`
file. Existing archives/checksums are refused. Send students the ZIP and its
checksum; they do not need the repository or any conversion directory.

The runtime snapshot was exported from Git objects at
`96c661e6a45db59b0e0d161d364fb0a813bd8020`, including the complete `src/` tree,
upstream README, and license. It includes no local patches or build products.
The native builder verifies its source hashes before compiling. Do not change
its version independently of the backend without compatibility testing.

The model, tokenizer, API, referee HTML/CSS/JavaScript, and GIF renderer were
copied from the working classroom version. Keep its attribution, model card,
and conversion provenance with any redistributed copy. This package does not
assign a new license to the model weights. The included upstream model card
does not state an explicit model license and is preserved unchanged.

Only the one small Python dependency is fetched during root/laptop setup;
normal play works without internet. For an offline class, prepare an optional
wheelhouse for `chess==1.11.2` and install it into each private venv. The provided
quick start assumes internet access during initial pip setup. OS package
installation is also a one-time prerequisite, rather than an automatic action
of the helper.
