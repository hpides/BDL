#!/usr/bin/env python3
"""Build a separate Chess Llama backend without editing an existing runtime."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
SOURCES = ["nn/nn-quants.cpp", "nn/nn-core.cpp", "nn/nn-executor.cpp", "nn/nn-network.cpp",
           "nn/llamafile/sgemm.cpp", "nn/nn-cpu-ops.cpp", "nn/nn-cpu.cpp", "tokenizer.cpp", "llm.cpp", "app.cpp"]
RUNTIME_COMMIT = "96c661e6a45db59b0e0d161d364fb0a813bd8020"


def runtime_revision(runtime):
    """Accept a Git checkout or the bundled, hash-checked upstream snapshot."""
    snapshot = runtime / "UPSTREAM.json"
    if snapshot.is_file():
        metadata = json.loads(snapshot.read_text())
        commit = metadata["commit"]
        files = metadata["files"]
        required = {"src/" + name for name in SOURCES} | {"src/dllama.cpp"}
        if not required <= files.keys():
            raise ValueError("Runtime snapshot is incomplete")
        actual = {p.relative_to(runtime).as_posix() for p in (runtime / "src").rglob("*") if p.is_file()}
        expected = {name for name in files if name.startswith("src/")}
        if actual != expected:
            raise ValueError("Runtime snapshot has missing or unexpected source files")
        for name, digest in files.items():
            path = runtime / name
            if (Path(name).is_absolute() or ".." in Path(name).parts or path.is_symlink()
                    or not path.resolve().is_relative_to(runtime.resolve())
                    or hashlib.sha256(path.read_bytes()).hexdigest() != digest):
                raise ValueError(f"Runtime snapshot checksum mismatch: {name}")
    else:
        commit = subprocess.check_output(["git", "-C", str(runtime), "rev-parse", "HEAD"], text=True).strip()
    if commit != RUNTIME_COMMIT:
        raise ValueError("Build against the lab's Distributed Llama v0.16.3 checkout")
    return commit


def build(runtime, output, jobs=2, worker=False):
    runtime, output = runtime.resolve(), output.resolve()
    commit = runtime_revision(runtime)
    compiler = shutil.which("g++")
    if compiler is None:
        raise ValueError("Install g++/build-essential first")
    output.mkdir(parents=True, exist_ok=False)
    flags = ["-std=c++11", "-O3", "-march=native", "-mtune=native", "-pthread", "-I", str(runtime / "src")]
    sources = [runtime / "src" / name for name in SOURCES]
    sources.append(runtime / "src/dllama.cpp" if worker else HERE / "chessllama_backend.cpp")
    objects = [output / f"part-{index}.o" for index in range(len(sources))]

    def compile_one(item):
        source, target = item
        subprocess.run([compiler, *flags, "-c", str(source), "-o", str(target)], check=True)

    with ThreadPoolExecutor(max_workers=jobs) as pool:
        list(pool.map(compile_one, zip(sources, objects)))
    binary = output / ("dllama-chess-worker" if worker else "dllama-chessllama")
    subprocess.run([compiler, *map(str, objects), "-pthread", "-o", str(binary)], check=True)
    (output / "BUILD.json").write_text(json.dumps(dict(runtime_commit=commit, compiler=compiler,
        flags=flags, source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}), indent=2) + "\n")
    print(f"{'Worker' if worker else 'Backend'}: {binary}")
    return binary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="New directory; existing paths are refused")
    parser.add_argument("--jobs", type=int, choices=range(1, 5), default=2)
    parser.add_argument("--worker", action="store_true", help="Build the stock worker into the separate output directory")
    args = parser.parse_args()
    build(args.runtime, args.output, args.jobs, args.worker)
