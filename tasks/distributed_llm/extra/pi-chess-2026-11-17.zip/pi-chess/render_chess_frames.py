#!/usr/bin/env python3
"""Render SVG frames with system librsvg/Cairo, outside the referee's venv.

Uses only the Python standard library. Running with /usr/bin/python3 avoids
mixing Conda's GLib libraries with the desktop's SVG rendering libraries.
"""
import argparse
import ctypes as C
import os
from pathlib import Path
import sys


class GError(C.Structure):
    _fields_ = [("domain", C.c_uint32), ("code", C.c_int), ("message", C.c_char_p)]


class Rectangle(C.Structure):
    _fields_ = [(name, C.c_double) for name in ("x", "y", "width", "height")]


class SvgRasterizer:
    def __init__(self):
        try:
            self.rsvg = C.CDLL("librsvg-2.so.2")
            self.cairo = C.CDLL("libcairo.so.2")
            self.gobject = C.CDLL("libgobject-2.0.so.0")
            self.glib = C.CDLL("libglib-2.0.so.0")
        except OSError as error:
            raise RuntimeError("SVG rendering needs the system libraries: "
                               "sudo apt install librsvg2-2 libcairo2") from error
        p, ep = C.c_void_p, C.POINTER(GError)
        functions = [
            (self.rsvg, "rsvg_handle_new_from_data", [C.c_char_p, C.c_size_t, C.POINTER(ep)], p),
            (self.rsvg, "rsvg_handle_render_document", [p, p, C.POINTER(Rectangle), C.POINTER(ep)], C.c_int),
            (self.gobject, "g_object_unref", [p], None),
            (self.glib, "g_error_free", [ep], None),
            (self.cairo, "cairo_image_surface_create", [C.c_int, C.c_int, C.c_int], p),
            (self.cairo, "cairo_create", [p], p),
            (self.cairo, "cairo_set_source_rgb", [p, C.c_double, C.c_double, C.c_double], None),
            (self.cairo, "cairo_paint", [p], None),
            (self.cairo, "cairo_status", [p], C.c_int),
            (self.cairo, "cairo_surface_write_to_png", [p, C.c_char_p], C.c_int),
            (self.cairo, "cairo_status_to_string", [C.c_int], C.c_char_p),
            (self.cairo, "cairo_destroy", [p], None),
            (self.cairo, "cairo_surface_destroy", [p], None),
        ]
        for library, name, arguments, result in functions:
            function = getattr(library, name)
            function.argtypes, function.restype = arguments, result

    def rsvg_error(self, error, fallback):
        if not error:
            return RuntimeError(fallback)
        message = error.contents.message.decode("utf-8", errors="replace")
        self.glib.g_error_free(error)
        return RuntimeError(message)

    def check_cairo(self, status):
        if status:
            raise RuntimeError(self.cairo.cairo_status_to_string(status).decode("utf-8"))

    def render(self, source, target, size=480):
        data = Path(source).read_bytes()
        error = C.POINTER(GError)()
        handle = self.rsvg.rsvg_handle_new_from_data(data, len(data), C.byref(error))
        if not handle:
            raise self.rsvg_error(error, "Unable to parse board SVG")
        surface, context = None, None
        try:
            surface = self.cairo.cairo_image_surface_create(0, size, size)  # ARGB32
            context = self.cairo.cairo_create(surface)
            self.check_cairo(self.cairo.cairo_status(context))
            # Paint an opaque paper background before rendering any SVG content.
            self.cairo.cairo_set_source_rgb(context, 246 / 255, 244 / 255, 236 / 255)
            self.cairo.cairo_paint(context)
            viewport = Rectangle(0, 0, size, size)
            if not self.rsvg.rsvg_handle_render_document(handle, context, C.byref(viewport), C.byref(error)):
                raise self.rsvg_error(error, "Unable to render board SVG")
            self.check_cairo(self.cairo.cairo_status(context))
            self.check_cairo(self.cairo.cairo_surface_write_to_png(surface, os.fsencode(target)))
        finally:
            if context:
                self.cairo.cairo_destroy(context)
            if surface:
                self.cairo.cairo_surface_destroy(surface)
            self.gobject.g_object_unref(handle)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--size", type=int, default=480)
    args = parser.parse_args(argv)
    if not 1 <= args.size <= 4096:
        parser.error("--size must be 1..4096")
    try:
        rasterizer = SvgRasterizer()
        frames = sorted(args.directory.glob("*.svg"))
        if not frames:
            raise ValueError("No SVG frames found")
        for source in frames:
            rasterizer.render(source, source.with_suffix(".png"), args.size)
    except (OSError, RuntimeError, ValueError) as error:
        print(f"SVG frame rendering failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
