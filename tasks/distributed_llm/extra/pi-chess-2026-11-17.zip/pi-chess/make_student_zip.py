#!/usr/bin/env python3
"""Create a clean, checksum-verified student ZIP from an explicit file list."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

from pi_chess import HERE, digest, safe_file, verify_bundle

FILES = '''README.md MAINTAINER.md PORTABLE_VALIDATION.json DISTRIBUTED_LLAMA_LICENSE.txt
MODEL_CARD.md PARITY_CHECK.json PROVENANCE.json build_chessllama.py pi_chess.py
make_student_zip.py chess_match.py chessllama_api.py chessllama_backend.cpp
chessllama_tokens.py config.json dllama_model_chess-llama_f32.m
dllama_tokenizer_chess-llama.t generation_config.json render_chess_frames.py
requirements.txt special_tokens_map.json tokenizer.json tokenizer_config.json
tests/test_portable_setup.py'''.split()


def release_files(base=HERE):
    upstream = json.loads((base / 'runtime/UPSTREAM.json').read_text())
    files = sorted(FILES + ['runtime/UPSTREAM.json'] + ['runtime/' + name for name in upstream['files']])
    if len(files) != len(set(files)):
        raise ValueError('Duplicate release filename')
    for name in files:
        path = safe_file(base, name)
        if not path.is_file():
            raise ValueError(f'Missing release file: {name}')
    return files


def refresh_manifest(base=HERE):
    names = release_files(base)
    content = ''.join(f'{digest(safe_file(base, name))}  {name}\n' for name in names)
    (base / 'SHA256SUMS').write_text(content)
    return names


def package(output, base=HERE):
    output = output.resolve()
    checksum = output.with_name(output.name + '.sha256')
    if output.exists() or checksum.exists():
        raise ValueError('Archive or checksum already exists. Choose a fresh output name; files are never overwritten.')
    if output.suffix != '.zip':
        raise ValueError('Use an output filename ending in .zip')
    expected = verify_bundle(base)
    if set(expected) != set(release_files(base)):
        raise ValueError('Manifest differs from the explicit release list. Refresh it after reviewing changes.')
    output.parent.mkdir(parents=True, exist_ok=True)
    created = False
    checksum_created = False
    try:
        with output.open('xb') as destination:
            created = True
            with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
                for name in sorted([*expected, 'SHA256SUMS']):
                    info = zipfile.ZipInfo('pi-chess/' + name, date_time=(2026, 11, 17, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_DEFLATED
                    info.external_attr = (0o100644 << 16)
                    info.create_system = 3
                    value = hashlib.sha256()
                    with safe_file(base, name).open('rb') as source, archive.open(info, 'w') as target:
                        for block in iter(lambda: source.read(1024 * 1024), b''):
                            value.update(block)
                            target.write(block)
                    if name in expected and value.hexdigest() != expected[name]:
                        raise ValueError(f'File changed during packaging: {name}')
        with zipfile.ZipFile(output) as archive:
            if archive.testzip() is not None:
                raise ValueError('Archive CRC validation failed')
        with checksum.open('x') as file:
            checksum_created = True
            file.write(f'{digest(output)}  {output.name}\n')
    except BaseException:
        if created:
            output.unlink(missing_ok=True)
        if checksum_created:
            checksum.unlink(missing_ok=True)
        raise
    print(f'Archive: {output} ({output.stat().st_size / 1024 / 1024:.1f} MiB)')
    print(f'Checksum: {checksum}')
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='New .zip file; existing archives are refused')
    parser.add_argument('--refresh-manifest', action='store_true', help='Recalculate the explicit release files after intentional changes')
    args = parser.parse_args(argv)
    try:
        if args.refresh_manifest:
            refresh_manifest()
        package(args.output)
    except (OSError, ValueError) as error:
        parser.exit(1, f'Packaging stopped: {error}\n')


if __name__ == '__main__':
    main()
