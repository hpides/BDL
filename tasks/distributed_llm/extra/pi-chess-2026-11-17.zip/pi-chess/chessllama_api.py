#!/usr/bin/env python3
"""Serve Chess Llama through Distributed Llama's native move-token backend.

The Pi API root needs Python's chess package, but does not need PyTorch.
Existing dllama workers receive their model slices through the normal protocol.
"""
import argparse
from http.server import HTTPServer
import json
import math
from pathlib import Path
import random
import subprocess
import sys

from chess_match import api_handler, chess, replay
from chessllama_tokens import load_vocab

MARKER = "@CHESSLLAMA@"
MODEL_ID = "chess-llama-f32"
RESULTS = {"<white_wins>": "1-0", "<black_wins>": "0-1"}


class NativeBackend:
    def __init__(self, command):
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        text=True, bufsize=1)
        try:
            ready = self.read()
            if not ready.get("ready") or ready.get("vocab_size") != 1974:
                raise ValueError("Backend did not load the expected model")
            self.context_size = ready["context_size"]
        except BaseException:
            self.close()
            raise

    def read(self):
        for line in self.process.stdout:
            if line.startswith(MARKER):
                value = json.loads(line[len(MARKER):])
                if "error" in value:
                    raise ValueError(value["error"])
                return value
            print(line, end="", file=sys.stderr, flush=True)
        raise RuntimeError(f"Native backend exited (code {self.process.poll()}); inspect its terminal")

    def evaluate(self, ids, candidates, *, return_logits=False):
        if self.process.poll() is not None:
            raise RuntimeError("Native backend is no longer running")
        request = dict(ids=ids, candidates=candidates)
        if return_logits:
            request["return_logits"] = True
        self.process.stdin.write(json.dumps(request) + "\n")
        self.process.stdin.flush()
        return self.read()

    def close(self):
        if self.process.stdin:
            try:
                self.process.stdin.close()
            except OSError:
                pass
        try:
            self.process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        if self.process.stdout:
            self.process.stdout.close()


def sample_prediction(logits, candidates, temperature):
    """Sample softmax(logits / temperature) over legal, non-excluded IDs only."""
    if (not isinstance(logits, list) or len(logits) != 1974
            or not all(isinstance(x, (int, float)) and math.isfinite(x) for x in logits)):
        raise ValueError("Backend must return 1974 finite logits for temperature sampling")
    maximum = max(logits[index] for index in candidates)
    # Subtract before dividing to keep very small temperatures numerically safe.
    weights = [math.exp((logits[index] - maximum) / temperature) for index in candidates]
    selected = random.choices(candidates, weights=weights, k=1)[0]
    global_maximum = max(logits)
    total = math.fsum(math.exp(value - global_maximum) for value in logits)
    return dict(id=selected, logit=logits[selected],
                probability=math.exp(logits[selected] - global_maximum) / total,
                sampling_probability=weights[candidates.index(selected)] / math.fsum(weights))


class ChessLlamaPolicy:
    model_id = MODEL_ID

    def __init__(self, vocab, backend):
        self.vocab, self.backend = vocab, backend
        self.moves = {value: key for key, value in vocab.items()}

    def choose(self, payload):
        temperature = payload.get("temperature", 0.0)
        if isinstance(temperature, bool) or not isinstance(temperature, (int, float)):
            raise ValueError("temperature must be a finite number greater than or equal to zero")
        try:
            temperature = float(temperature)
        except OverflowError:
            raise ValueError("temperature must be finite") from None
        if not math.isfinite(temperature) or temperature < 0:
            raise ValueError("temperature must be finite and greater than or equal to zero")
        board = replay(payload["initial_fen"], payload["history"])
        if board.root().fen() != chess.STARTING_FEN:
            raise ValueError("Chess Llama needs a complete move history from the standard starting position")
        if board.fen() != chess.Board(payload["fen"]).fen():
            raise ValueError("FEN disagrees with the supplied history")
        if board.is_game_over():
            raise ValueError("The position is terminal")
        result = payload.get("result", "<white_wins>" if board.turn else "<black_wins>")
        if result not in RESULTS:
            raise ValueError("Chess Llama supports white-wins or black-wins conditioning; no draw token was trained")
        ids = [self.vocab[RESULTS[result]]] + [self.vocab[m.uci()] for m in board.move_stack]
        if len(ids) > self.backend.context_size:
            raise ValueError("Chess Llama's 256-token context is exhausted; history cannot be truncated safely")
        excluded = payload.get("excluded_moves", [])
        if not isinstance(excluded, list) or not all(isinstance(m, str) for m in excluded):
            raise ValueError("excluded_moves must be a list of UCI strings")
        legal = sorted(m.uci() for m in board.legal_moves if m.uci() not in excluded)
        if not legal:
            raise ValueError("No legal candidates remain")
        candidates = [self.vocab[m] for m in legal]
        if temperature > 0:
            prediction = self.backend.evaluate(ids, candidates, return_logits=True)
            prediction = sample_prediction(prediction.get("logits"), candidates, temperature)
        else:
            prediction = self.backend.evaluate(ids, candidates)
        if prediction["id"] not in candidates:
            raise ValueError("Backend returned a token outside the legal candidate set")
        response = dict(move=self.moves[prediction["id"]], model=MODEL_ID,
                        probability=prediction["probability"], input_tokens=len(ids),
                        temperature=temperature)
        if "sampling_probability" in prediction:
            response["sampling_probability"] = prediction["sampling_probability"]
        return response


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--backend", type=Path, required=True)
    parser.add_argument("--workers", nargs="*", default=[])
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=9998)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args(argv)
    if len(args.workers) > 1 or args.threads < 1 or not 0 <= args.port <= 65535:
        parser.error("Use positive threads, a port from 0..65535, and at most one worker")
    bundle = args.bundle.resolve()
    command = [str(args.backend.resolve()), "--model", str(bundle / "dllama_model_chess-llama_f32.m"),
               "--tokenizer", str(bundle / "dllama_tokenizer_chess-llama.t"),
               "--buffer-float-type", "f32", "--nthreads", str(args.threads), "--max-seq-len", "256"]
    if args.workers:
        command.extend(["--workers", *args.workers])
    backend = None
    try:
        vocab = load_vocab(bundle / "tokenizer.json")
        backend = NativeBackend(command)
        policy = ChessLlamaPolicy(vocab, backend)
        with HTTPServer((args.host, args.port), api_handler(policy)) as server:
            print(f"Chess Llama API ready on {args.host}:{server.server_port}/v1", flush=True)
            server.serve_forever()
    except KeyboardInterrupt:
        return 130
    except (OSError, ValueError, RuntimeError) as error:
        print(f"API stopped: {error}", file=sys.stderr)
        return 1
    finally:
        if backend is not None:
            backend.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
