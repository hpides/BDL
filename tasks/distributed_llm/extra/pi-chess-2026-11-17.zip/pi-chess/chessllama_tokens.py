"""Resolve the complete Chess Llama WordLevel vocabulary without changing IDs."""
import json
from pathlib import Path
import re


def resolve_vocab(tokenizer):
    if tokenizer["model"]["type"] != "WordLevel":
        raise ValueError("Expected the publisher's WordLevel tokenizer")
    # HF stores 1971 base tokens in model.vocab and three more special tokens
    # in added_tokens. <unk> appears in both; the identical ID is intentional.
    vocab = dict(tokenizer["model"]["vocab"])
    for token in tokenizer.get("added_tokens", []):
        word, index = token["content"], token["id"]
        if word in vocab and vocab[word] != index:
            raise ValueError(f"Conflicting token ID for {word}")
        vocab[word] = index
    if len(vocab) != 1974 or set(vocab.values()) != set(range(1974)):
        raise ValueError("Invalid/missing token IDs after combining base and added tokens")
    expected = {"<unk>": 0, "1-0": 13, "0-1": 19, "<s>": 1971, "</s>": 1972, "<pad>": 1973}
    for word, index in expected.items():
        if vocab.get(word) != index:
            raise ValueError(f"Unexpected token ID for {word}")
    if sum(bool(re.fullmatch(r"[a-h][1-8][a-h][1-8][qrbn]?", word)) for word in vocab) != 1968:
        raise ValueError("Expected all 1968 UCI move tokens")
    return vocab


def load_vocab(path):
    return resolve_vocab(json.loads(Path(path).read_text(encoding="utf-8")))
