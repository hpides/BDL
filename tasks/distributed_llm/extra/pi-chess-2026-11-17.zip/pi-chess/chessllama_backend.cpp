// Chess move-token bridge for Distributed Llama v0.16.3.
// Uses the runtime's tensor-parallel engine, while bypassing its text tokenizer.
#include "app.hpp"
#include "json.hpp"
#include "nn/nn-network.hpp"
#include <algorithm>
#include <cmath>
#include <csignal>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using json = nlohmann::json;
static const char *MARKER = "@CHESSLLAMA@";

static void reply(const json &value) {
    std::fflush(stdout);
    std::cout << MARKER << value.dump() << std::endl;
}

static json evaluate(AppInferenceContext *context, const json &request) {
    std::vector<int> ids = request.at("ids").get<std::vector<int>>();
    std::vector<int> candidates = request.at("candidates").get<std::vector<int>>();
    const unsigned int vocab = context->header->vocabSize;
    if (ids.empty() || ids.size() > context->header->seqLen)
        throw std::invalid_argument("Input must contain 1..256 move/result tokens");
    if (candidates.empty()) throw std::invalid_argument("No candidate moves");
    for (int id : ids)
        if (id < 0 || static_cast<unsigned int>(id) >= vocab)
            throw std::invalid_argument("Input token outside the model vocabulary");
    for (int id : candidates)
        if (id < 0 || static_cast<unsigned int>(id) >= vocab)
            throw std::invalid_argument("Candidate outside the model vocabulary");

    // Recompute the full prefix for each position. Resetting positions to zero
    // also overwrites every KV-cache entry that can be attended to on this turn.
    context->inference->setBatchSize(1);
    for (unsigned int position = 0; position < ids.size(); position++) {
        context->inference->setPosition(position);
        context->inference->setToken(0, ids[position]);
        context->inference->forward();
    }
    float *logits = context->inference->logitsPipe;
    int best = candidates[0];
    for (int id : candidates) {
        if (!std::isfinite(logits[id])) throw std::runtime_error("Non-finite model logit");
        if (logits[id] > logits[best]) best = id;
    }
    float maximum = *std::max_element(logits, logits + vocab);
    double total = 0;
    for (unsigned int i = 0; i < vocab; i++) {
        if (!std::isfinite(logits[i])) throw std::runtime_error("Non-finite model logit");
        total += std::exp(double(logits[i] - maximum));
    }
    json result = {{"id", best}, {"logit", logits[best]},
                   {"probability", std::exp(double(logits[best] - maximum)) / total}};
    if (request.value("return_logits", false))
        result["logits"] = std::vector<float>(logits, logits + vocab);
    return result;
}

static void bridge(AppInferenceContext *context) {
    reply({{"ready", true}, {"vocab_size", context->header->vocabSize},
           {"context_size", context->header->seqLen}, {"nodes", context->args->nWorkers + 1}});
    std::string line;
    while (std::getline(std::cin, line)) {
        try {
            json request = json::parse(line);
            // Parse/range errors are recoverable; inference/network errors exit
            // the process so the API cannot silently keep using broken state.
            try { reply(evaluate(context, request)); }
            catch (const std::invalid_argument &error) { reply({{"error", error.what()}}); }
            catch (const json::exception &error) { reply({{"error", error.what()}}); }
        } catch (const json::exception &error) { reply({{"error", error.what()}}); }
    }
}

int main(int argc, char **argv) {
    try {
        std::signal(SIGPIPE, SIG_IGN);
        AppCliArgs args = AppCliArgs::parse(argc, argv, false);
        args.benchmark = false;
        if (args.help) {
            std::cout << "dllama-chessllama --model FILE.m --tokenizer FILE.t "
                         "--buffer-float-type f32 --nthreads 4 [--workers IP:PORT]\n"
                         "Reads JSON lines with ids and candidates; writes @CHESSLLAMA@ JSON.\n";
            return 0;
        }
        if (!args.modelPath || !args.tokenizerPath) throw std::invalid_argument("Model and tokenizer paths are required");
        if (args.nWorkers > 1) throw std::invalid_argument("Use one root plus at most one worker for vocabulary size 1974");
        LlmHeader header = loadLlmHeader(args.modelPath, args.maxSeqLen, args.syncType);
        if (header.archType != LLAMA || header.vocabSize != 1974 || header.origSeqLen != 256)
            throw std::invalid_argument("Expected the 1974-token, 256-position Chess Llama checkpoint");
        if (header.weightType != F_32 || args.syncType != F_32)
            throw std::invalid_argument("This implementation uses F32 weights and F32 buffers");
        initQuants();
        initSockets();
        runInferenceApp(&args, bridge);
        cleanupSockets();
        return 0;
    } catch (const std::exception &error) {
        std::cerr << "Chess Llama backend stopped: " << error.what() << std::endl;
        return 1;
    }
}
