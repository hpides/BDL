#!/usr/bin/env python3
"""Isolated setup and foreground launch commands for the portable Pi Chess bundle."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import shlex
import shutil
import subprocess
import sys
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import urlopen
from uuid import uuid4

HERE = Path(__file__).resolve().parent
STATE = '.pi-chess'
OWNER = {'application': 'pi-chess', 'format': 1}
PORT = 10098


def run(command, **kwargs):
    print('+ ' + shlex.join(map(str, command)), flush=True)
    return subprocess.run(list(map(str, command)), check=True, **kwargs)


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def safe_file(base, name):
    relative = PurePosixPath(name)
    path = base / name
    if (not name or relative.is_absolute() or '..' in relative.parts or '\\' in name
            or path.is_symlink() or not path.resolve().is_relative_to(base.resolve())):
        raise ValueError(f'Unsafe bundle path: {name}')
    return path


def verify_bundle(base=HERE):
    files = {}
    for line in (base / 'SHA256SUMS').read_text().splitlines():
        checksum, name = line.split('  ', 1)
        if name in files or len(checksum) != 64:
            raise ValueError('Invalid or duplicate checksum entry')
        path = safe_file(base, name)
        if not path.is_file() or digest(path) != checksum:
            raise ValueError(f'Bundle checksum mismatch or missing file: {name}. Extract a fresh copy of the ZIP.')
        files[name] = checksum
    required = {'pi_chess.py', 'build_chessllama.py', 'runtime/UPSTREAM.json', 'chess_match.py',
                'dllama_model_chess-llama_f32.m', 'dllama_tokenizer_chess-llama.t', 'requirements.txt'}
    if not required <= files.keys():
        raise ValueError('Incomplete bundle checksum manifest')
    print(f'Verified {len(files)} bundled files.', flush=True)
    return files


def state_directory(create=False, base=HERE):
    directory = base / STATE
    if directory.is_symlink():
        raise ValueError(f'Refusing a symlink at {directory}')
    if not directory.exists():
        if not create:
            raise ValueError('Run the setup command for this computer first; see README.md.')
        directory.mkdir()
        (directory / 'OWNER.json').write_text(json.dumps(OWNER) + '\n')
    marker = directory / 'OWNER.json'
    if not marker.is_file() or json.loads(marker.read_text()) != OWNER:
        raise ValueError(f'{directory} already exists and is not owned by this add-on. Extract to a fresh folder.')
    return directory


def settings(base=HERE):
    directory = state_directory(base=base)
    path = directory / 'settings.json'
    return json.loads(path.read_text()) if path.is_file() else {}


def save_settings(values, base=HERE):
    directory = state_directory(create=True, base=base)
    temporary = directory / ('settings-' + uuid4().hex + '.tmp')
    temporary.write_text(json.dumps(values, indent=2) + '\n')
    temporary.replace(directory / 'settings.json')


def local_path(value, base=HERE):
    path = safe_file(base, value)
    if not path.resolve().is_relative_to((base / STATE).resolve()):
        raise ValueError('Setup paths must stay inside the private .pi-chess directory')
    return path


def private_python(values, base=HERE):
    if 'python' not in values:
        raise ValueError('Python environment missing; run setup laptop or setup root first.')
    relative = PurePosixPath(values['python'])
    python = base / relative
    # The executable may link to system Python; its containing directory must be private.
    if (relative.is_absolute() or '..' in relative.parts or '\\' in str(relative)
            or not relative.parts or relative.parts[0] != STATE
            or not python.parent.resolve().is_relative_to((base / STATE).resolve())):
        raise ValueError('Python environment must stay inside the private .pi-chess directory')
    if not python.is_file():
        raise ValueError('Private environment missing. Rerun setup on this computer.')
    return python


def ensure_python(values):
    if 'python' in values:
        python = private_python(values)
        run([python, '-I', '-c', 'import chess; assert chess.__version__ == "1.11.2"'])
        return python
    directory = state_directory() / ('python-' + uuid4().hex)
    directory.mkdir()
    python_base = Path('/usr/bin/python3') if Path('/usr/bin/python3').is_file() else Path(sys.executable)
    try:
        run([python_base, '-I', '-m', 'venv', directory / 'venv'])
    except subprocess.CalledProcessError:
        raise ValueError('Could not create an isolated venv. On Debian/Ubuntu install python3-venv, then rerun setup.') from None
    python = directory / 'venv/bin/python'
    run([python, '-I', '-m', 'pip', 'install', '--isolated', '--no-cache-dir', '--disable-pip-version-check',
         '-r', HERE / 'requirements.txt'])
    values['python'] = python.relative_to(HERE).as_posix()
    return python


def port(value):
    number = int(value)
    if not 1 <= number <= 65535:
        raise argparse.ArgumentTypeError('use a port from 1 to 65535')
    return number


def positive(value):
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError('must be positive')
    return number


def temperature(value):
    number = float(value)
    if not math.isfinite(number) or number < 0:
        raise argparse.ArgumentTypeError('must be finite and nonnegative')
    return number


def worker_address(value):
    try:
        parsed = urlsplit('//' + value)
        if (not parsed.hostname or parsed.username is not None or parsed.password is not None
                or parsed.path or parsed.query or parsed.fragment or any(c.isspace() for c in value)):
            raise ValueError()
        number = PORT if parsed.port is None else parsed.port
        port(str(number))
        host = f'[{parsed.hostname}]' if ':' in parsed.hostname else parsed.hostname
        return f'{host}:{number}'
    except (ValueError, argparse.ArgumentTypeError):
        raise argparse.ArgumentTypeError('use a worker hostname/IP, optionally followed by :port') from None


def api_address(value):
    try:
        parsed = urlsplit(value if '://' in value else 'http://' + worker_address(value))
        if (parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username is not None
                or parsed.password is not None or parsed.query or parsed.fragment
                or parsed.path.rstrip('/') not in ('', '/v1') or any(c.isspace() for c in value)):
            raise ValueError()
        if parsed.port is not None:
            port(str(parsed.port))
        return f'{parsed.scheme}://{parsed.netloc}/v1'
    except (ValueError, argparse.ArgumentTypeError):
        raise argparse.ArgumentTypeError('use an API IP/hostname or an http(s) URL ending in /v1') from None


def check_gif_support():
    if not (shutil.which('magick') or shutil.which('convert')):
        raise ValueError('GIF export needs laptop packages: sudo apt install imagemagick librsvg2-2 libcairo2')
    environment = dict(os.environ)
    for name in ('LD_LIBRARY_PATH', 'LD_PRELOAD', 'PYTHONHOME', 'PYTHONPATH'):
        environment.pop(name, None)
    result = subprocess.run(['/usr/bin/python3', '-c',
                             'from render_chess_frames import SvgRasterizer; SvgRasterizer()'],
                            cwd=HERE, env=environment, capture_output=True, text=True)
    if result.returncode:
        raise ValueError('GIF export needs system Python and laptop libraries: sudo apt install python3 librsvg2-2 libcairo2')


def setup(args):
    verify_bundle()
    directory = state_directory(create=True)
    values = settings()
    if args.role == 'laptop':
        check_gif_support()
        ensure_python(values)
        values['laptop'] = dict(api_a=args.api_a, api_b=args.api_b, temperature=args.temperature,
                                web_port=args.web_port)
    else:
        from build_chessllama import build
        previous = values.get(args.role, {})
        if previous and not args.rebuild:
            binary = local_path(previous['binary'])
            if not binary.is_file():
                raise ValueError('Previous build is missing. Rerun setup with --rebuild.')
            print('Reusing the completed private build. Use --rebuild to compile again.', flush=True)
        else:
            binary = build(HERE / 'runtime', directory / (args.role + '-' + uuid4().hex),
                           jobs=args.jobs, worker=args.role == 'worker')
        if args.role == 'root':
            ensure_python(values)
        values[args.role] = dict(binary=binary.relative_to(HERE).as_posix(),
                                 threads=args.threads, port=args.port)
        if args.role == 'root':
            values['root']['worker'] = args.worker
    save_settings(values)
    print(f'Setup complete for {args.role}. Everything created is inside {HERE / STATE}.', flush=True)
    next_command = {'root': 'api', 'worker': 'worker', 'laptop': 'play'}[args.role]
    print(f'Next time: python3 pi_chess.py {next_command}', flush=True)


def role_settings(values, role):
    if role not in values:
        raise ValueError(f'Run python3 pi_chess.py setup {role} on this computer first.')
    return values[role]


def api_command(args, values):
    root = role_settings(values, 'root')
    command = [str(private_python(values)), str(HERE / 'chessllama_api.py'), '--bundle', str(HERE),
               '--backend', str(local_path(root['binary'])), '--host', args.host,
               '--port', str(args.port or root['port']), '--threads', str(args.threads or root['threads'])]
    worker = None if args.solo else args.worker or root.get('worker')
    if worker:
        command += ['--workers', worker]
    return command


def worker_command(args, values):
    worker = role_settings(values, 'worker')
    return [str(local_path(worker['binary'])), 'worker', '--port', str(args.port or worker['port']),
            '--nthreads', str(args.threads or worker['threads'])]


def play_command(args, values):
    laptop = role_settings(values, 'laptop')
    command = [str(private_python(values)), str(HERE / 'chess_match.py'), 'match',
               '--api-a', args.api_a or laptop['api_a'], '--protocol-a', 'chessllama',
               '--api-b', args.api_b or laptop['api_b'], '--protocol-b', 'chessllama',
               '--temperature', str(laptop['temperature'] if args.temperature is None else args.temperature),
               '--mode', args.mode, '--human-color', args.human_color,
               '--max-plies', '256', '--timeout', '600', '--keep-web',
               '--web-port', str(args.web_port or laptop['web_port'])]
    if args.no_eval:
        command.append('--no-eval')
    return command


def check_apis(args, values):
    laptop = role_settings(values, 'laptop')
    sides = ('a', 'b') if args.mode == 'watch' else (args.mode[-1],)
    for side in sides:
        url = getattr(args, 'api_' + side) or laptop['api_' + side]
        try:
            with urlopen(url + '/models', timeout=10) as response:
                data = json.load(response)
            if not any(item.get('id') == 'chess-llama-f32' for item in data.get('data', [])):
                raise ValueError('API did not identify chess-llama-f32')
        except (OSError, ValueError, URLError) as error:
            raise ValueError(f'API {side.upper()} unavailable at {url}: {error}. Start its worker, then its API; check the configured IP/port.') from None
        print(f'API {side.upper()} ready: {url}', flush=True)


def launch(command, cwd=HERE):
    print('+ ' + shlex.join(command), flush=True)
    os.chdir(cwd)
    for name in ('PYTHONHOME', 'PYTHONPATH'):
        os.environ.pop(name, None)
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.execv(command[0], command)


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    commands = result.add_subparsers(dest='command', required=True)
    commands.add_parser('verify', help='Check the included file checksums; no dependencies required')
    prepare = commands.add_parser('setup', help='One-time isolated setup on this computer')
    prepare.add_argument('role', choices=['root', 'worker', 'laptop'])
    prepare.add_argument('--worker', type=worker_address, help='Root: worker IP/hostname; omit for a root-only player')
    prepare.add_argument('--api-a', type=api_address, default=api_address('10.0.0.1'))
    prepare.add_argument('--api-b', type=api_address, default=api_address('10.0.0.3'))
    prepare.add_argument('--port', type=port, default=PORT, help='API/worker port (default: 10098)')
    prepare.add_argument('--web-port', type=port, default=8000)
    prepare.add_argument('--threads', type=positive, default=4)
    prepare.add_argument('--temperature', type=temperature, default=0.7)
    prepare.add_argument('--jobs', type=int, choices=range(1, 5), default=1, help='Parallel compiler jobs (default: 1 for Pi memory use)')
    prepare.add_argument('--rebuild', action='store_true', help='Create a fresh private build, keeping earlier builds')
    api = commands.add_parser('api', help='Start a root API in this terminal')
    api.add_argument('--host', default='0.0.0.0')
    api.add_argument('--port', type=port)
    api.add_argument('--threads', type=positive)
    worker_choice = api.add_mutually_exclusive_group()
    worker_choice.add_argument('--worker', type=worker_address)
    worker_choice.add_argument('--solo', action='store_true', help='Temporarily run on the root alone')
    worker = commands.add_parser('worker', help='Start a worker in this terminal')
    worker.add_argument('--port', type=port)
    worker.add_argument('--threads', type=positive)
    play = commands.add_parser('play', help='Open the referee session; click Start game in your browser')
    check = commands.add_parser('check', help='Check API connectivity from the laptop')
    for command in (play, check):
        command.add_argument('--api-a', type=api_address)
        command.add_argument('--api-b', type=api_address)
        command.add_argument('--mode', choices=['watch', 'human-a', 'human-b'], default='watch')
    play.add_argument('--human-color', choices=['white', 'black'], default='white')
    play.add_argument('--temperature', type=temperature)
    play.add_argument('--web-port', type=port)
    play.add_argument('--no-eval', action='store_true')
    return result


def main(argv=None):
    if sys.version_info < (3, 9) or not sys.platform.startswith('linux'):
        print('This bundle supports Linux with Python 3.9+ (64-bit Raspberry Pi OS / Debian / Ubuntu).', file=sys.stderr)
        return 1
    args = parser().parse_args(argv)
    try:
        if args.command == 'verify':
            verify_bundle()
        elif args.command == 'setup':
            setup(args)
        else:
            values = settings()
            if args.command == 'check':
                check_apis(args, values)
            elif args.command == 'api':
                launch(api_command(args, values))
            elif args.command == 'worker':
                launch(worker_command(args, values))
            else:
                check_gif_support()
                command = play_command(args, values)
                games = HERE / 'games'
                if games.is_symlink():
                    raise ValueError('Refusing a symlink at the games directory')
                games.mkdir(exist_ok=True)
                launch(command, cwd=games)
    except KeyboardInterrupt:
        print('Stopped. Existing files have been kept.', file=sys.stderr)
        return 130
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as error:
        print(f'Pi Chess: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
